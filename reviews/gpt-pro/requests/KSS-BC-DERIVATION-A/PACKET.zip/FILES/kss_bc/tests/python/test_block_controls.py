from __future__ import annotations

import itertools

import numpy as np

from kss_bc.tests.python.oracle import build_expanded_design
from kss_bc.tests.python.test_dense_oracle import fixture, model_data


def test_rank_one_block_inverse_derivatives_have_registered_signs() -> None:
    control_loading = np.array([[0.20, -0.05], [-0.10, 0.25], [0.15, 0.10]])
    control_projection = control_loading @ control_loading.T
    direction = np.sqrt(np.array([0.2, 0.3, 0.5]))
    residual = np.array([0.7, -0.25, 0.4])
    leverage = 0.27

    def inverse_residual(value: float) -> np.ndarray:
        maker = (
            np.eye(direction.size)
            - control_projection
            - value * np.outer(direction, direction)
        )
        return np.linalg.solve(maker, residual)

    maker = (
        np.eye(direction.size)
        - control_projection
        - leverage * np.outer(direction, direction)
    )
    inverse = np.linalg.inv(maker)
    inverse_direction = inverse @ direction
    first = direction @ inverse @ residual
    second = direction @ inverse_direction
    analytic_first = inverse_direction * first
    analytic_half_second = inverse_direction * second * first

    step = 1e-5
    center = inverse_residual(leverage)
    finite_first = (
        inverse_residual(leverage + step)
        - inverse_residual(leverage - step)
    ) / (2 * step)
    finite_half_second = (
        inverse_residual(leverage + step)
        - 2 * center
        + inverse_residual(leverage - step)
    ) / (2 * step**2)
    assert np.allclose(finite_first, analytic_first, atol=2e-9, rtol=2e-9)
    assert np.allclose(
        finite_half_second, analytic_half_second, atol=3e-6, rtol=3e-6
    )


def test_joint_projection_splits_into_fe_and_residualized_controls() -> None:
    data = fixture()
    design = build_expanded_design(
        **model_data(data), deletion="match", deletion_id=data["match"]
    )
    fe_columns = np.any(design.worker_rows != 0, axis=0) | np.any(
        design.firm_rows != 0, axis=0
    )
    x_fe = design.x[:, fe_columns]
    controls = design.x[:, ~fe_columns]
    p_fe = x_fe @ np.linalg.inv(x_fe.T @ x_fe) @ x_fe.T
    residualized_controls = controls - p_fe @ controls
    control_projection = residualized_controls @ np.linalg.inv(
        residualized_controls.T @ residualized_controls
    ) @ residualized_controls.T
    p_full = design.x @ np.linalg.inv(design.x.T @ design.x) @ design.x.T
    assert np.allclose(p_full, p_fe + control_projection, atol=2e-12, rtol=2e-12)
    assert np.allclose(p_fe @ control_projection, 0, atol=2e-12, rtol=2e-12)

    for block in np.unique(design.deletion_id):
        use = design.deletion_id == block
        frequency_direction = np.ones(use.sum()) / np.sqrt(use.sum())
        p_block = p_fe[np.ix_(use, use)]
        leverage = float(frequency_direction @ p_block @ frequency_direction)
        assert np.allclose(
            p_block,
            leverage * np.outer(frequency_direction, frequency_direction),
            atol=2e-12,
            rtol=2e-12,
        )


def test_general_block_delta_adjustment_reduces_inverse_bias() -> None:
    block = np.array([0, 1])
    direction = np.sqrt(np.array([0.4, 0.6]))
    leverage = 0.30
    base_vector = np.r_[np.sqrt(leverage) * direction, np.repeat(np.sqrt(0.7 / 4), 4)]
    base_vector /= np.linalg.norm(base_vector)

    candidate = np.array([0.3, -0.2, 0.5, -0.4, 0.1, 0.6])
    control_vector = candidate - base_vector * (candidate @ base_vector)
    control_vector /= np.linalg.norm(control_vector)
    base_projection = np.outer(base_vector, base_vector)
    control_projection = np.outer(control_vector, control_vector)
    block_control = control_projection[np.ix_(block, block)]
    outcome_residual = np.array([0.7, -0.25])

    directions = np.array(list(itertools.product([-1.0, 1.0], repeat=6)))
    projected = (directions @ base_projection[block].T) @ direction
    residual = (directions @ (np.eye(6) - base_projection)[block].T) @ direction
    projected_sq = projected**2
    residual_sq = residual**2
    assert np.isclose(projected_sq.mean(), leverage, atol=2e-14)
    assert np.isclose(residual_sq.mean(), 1 - leverage, atol=2e-14)

    probes = 25
    experiments = 80_000
    rng = np.random.default_rng(20260815)
    counts = rng.multinomial(
        probes,
        np.full(directions.shape[0], 1 / directions.shape[0]),
        size=experiments,
    )
    p_mean = counts @ projected_sq / probes
    m_mean = counts @ residual_sq / probes
    p_fourth = counts @ (projected_sq**2) / probes
    m_fourth = counts @ (residual_sq**2) / probes
    mixed = counts @ (projected_sq * residual_sq) / probes
    total = p_mean + m_mean
    p_bar = p_mean / total
    m_bar = m_mean / total
    finite_variance = (
        m_bar**2 * p_fourth
        + p_bar**2 * m_fourth
        - 2 * p_bar * m_bar * mixed
    ) / probes
    finite_bias_m = (
        m_bar * p_fourth
        - p_bar * m_fourth
        + (m_bar - p_bar) * mixed
    ) / probes

    truth_maker = (
        np.eye(2)
        - block_control
        - leverage * np.outer(direction, direction)
    )
    truth = np.linalg.solve(truth_maker, outcome_residual)
    naive = np.empty((experiments, 2))
    adjusted = np.empty((experiments, 2))
    for experiment in range(experiments):
        maker = (
            np.eye(2)
            - block_control
            - p_bar[experiment] * np.outer(direction, direction)
        )
        inverse = np.linalg.inv(maker)
        base = inverse @ outcome_residual
        inverse_direction = inverse @ direction
        first = direction @ base
        second = direction @ inverse_direction
        naive[experiment] = base
        adjusted[experiment] = (
            base
            + finite_bias_m[experiment] * inverse_direction * first
            - finite_variance[experiment] * inverse_direction * second * first
        )

    naive_bias = np.linalg.norm(naive.mean(axis=0) - truth)
    adjusted_bias = np.linalg.norm(adjusted.mean(axis=0) - truth)
    assert adjusted_bias < 0.35 * naive_bias
