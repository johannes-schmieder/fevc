# Source map

| Repository path | SHA-256 | Note |
|---|---|---|
| `varcomp_hdfe_specification.md` | `8fb1c9bd5c5ab1238d05949794d3af9771241dea0ab4dc6c701e3cea9b9184f5` | Governing contract and required invariances. |
| `kss_bc/README.md` | `73973b1a75866d27c8aa49e6840a08307dd2a9556b9efb5286efd726c3a248f3` | Implemented and excluded scope. |
| `kss_bc/CHANGELOG.md` | `fddcfdfcfa9a482d3949307b240dff1217a44a01ba1f46c0db2066b5f99c0eb4` | Candidate history and API 9 repairs. |
| `kss_bc/docs/DECISIONS.md` | `6bf9b536af134da061b26c991e4a7c761cd3ad1df9e74766d8c13bb1cc30adbc` | Owner-authorized choices. |
| `kss_bc/docs/ESTIMATOR_CONTRACT.md` | `74b1a845f1fbff8c54f161a5c781ec6d63e84ec14267e3e156fae09086c990da` | Point-estimator formulas and deletion semantics. |
| `kss_bc/docs/JLA_FINITE_PROJECTION.md` | `27bbf09bd2a67c0278ab5f12c9162f195efd06c3d017f1711a44fff8f0836e56` | Candidate finite-projection and literal-copy derivation. |
| `kss_bc/docs/BLOCK_CONTROL_DERIVATION.md` | `fa066188aeb99e2df912ba0a64f79b9bae7250cb260ca4dbca1e43403cddf188` | Candidate block-control and rank-gate derivation. |
| `kss_bc/docs/NUMERICAL_ARCHITECTURE.md` | `bd533553c0d13c2bc09e9f6f9de1a4c5cd7cae23893efc6722c0f99145eac895` | Production numerical and graph architecture. |
| `kss_bc/docs/FAILURES_AND_RETURNS.md` | `4a8fa7928e4df3535242676a9bb421d25e3f92802cb58c42ce761f1264770f98` | Accepted and withheld return states. |
| `kss_bc/kss_bc.sthlp` | `10fba48ce1f421d3577543340180e4fd400157a1348d374798cab52045c14e6c` | User-facing disclosure. |
| `kss_bc/kss_bc.ado` | `2b7d366d4c67892c1d62c54086e79942f994d15799ea8079e776670e07df8cac` | Complete public control flow. |
| `kss_bc/kss_bc.mata` | `974e23b666bf7d3ecde5d467cd8e575ec6df10fee7597a233c79b5f109f8cadb` | Complete API 9 computational implementation. |
| `kss_bc/tests/python/test_frequency_probes.py` | `ca4b93fa638e4b25591f64c54200712a4780befa1333223931d1c68292e3830f` | Exhaustive frequency identities. |
| `kss_bc/tests/python/test_jla_formula.py` | `088c48286024cbabae07e11c4211307b830b57497e51f4327b7ca0c53df25477` | Symbolic and Monte Carlo finite-projection checks. |
| `kss_bc/tests/python/test_block_controls.py` | `ee7132764426caf92a66bc9cbbe94defb22f9a82f2136febb544825c24b7d721` | Block-control counterexample searches. |
| `kss_bc/tests/python/test_dense_oracle.py` | `f3588709c28b77a84c7632552d3c1915facf2c47ab0feac32c24a1f37f965a93` | Independent literal-expanded exact oracle. |
| `kss_bc/tests/python/test_package_layout.py` | `4094ab994f1016f24a52ba693773d57bac1fabaf9dac49427be2f6d40ff5bec2` | Static production gate assertions. |
| `kss_bc/tests/stata/test_frequency.do` | `c1ef2f804e851d6b7d1d853c1b2ab252200391a46ce3830d86bea2cfc0f2b517` | Finite-probe public frequency equivalence. |
| `kss_bc/tests/stata/test_graph_pruning.do` | `c26d57e7eaf95a1a56a0d1123986ce136f4de18b074889b9a6c62cd14c85a963` | Graph relabeling and tie withholding. |
| `kss_bc/tests/stata/test_failures.do` | `e23d10323374bf7283e3d1d667781e8c75b87d67532341ac9a3eac9e95b299ce` | Registered singular and ill-conditioned false-acceptance fixtures. |
| `kss_bc/tests/stata/test_jla_fixture.do` | `214906e04f15e1fc6d2625d2b698c7b3e573a268200de61556f0adf23235c372` | Public exact/JLA overlap. |
| `kss_bc/tests/stata/test_stale_runtime.do` | `b0c61fed9723afc335519f700ad4f291323fd5b57b4dea71b35ba6cd878c185c` | Runtime identity failure fixture. |
