from __future__ import annotations

from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
VERSION = "0.1.0-dev"
API_LEVEL = 6


def test_package_manifest_is_complete() -> None:
    manifest = (ROOT / "kss_bc.pkg").read_text(encoding="utf-8").splitlines()
    shipped = {
        line.removeprefix("f ").strip()
        for line in manifest
        if line.startswith("f ")
    }
    assert shipped == {"kss_bc.ado", "kss_bc.mata", "kss_bc.sthlp"}
    for relative in shipped:
        assert (ROOT / relative).is_file()


def test_version_identifiers_agree() -> None:
    assert VERSION in (ROOT / "kss_bc.ado").read_text(encoding="utf-8")
    assert VERSION in (ROOT / "kss_bc.mata").read_text(encoding="utf-8")
    assert VERSION in (ROOT / "kss_bc.sthlp").read_text(encoding="utf-8")
    toc = (ROOT / "stata.toc").read_text(encoding="utf-8").splitlines()
    assert toc[0] == f"v {VERSION}"


def test_mata_api_guard_agrees() -> None:
    ado = (ROOT / "kss_bc.ado").read_text(encoding="utf-8")
    mata = (ROOT / "kss_bc.mata").read_text(encoding="utf-8")
    assert f"kssbc__api_level() == {API_LEVEL}" in ado
    assert f"return({API_LEVEL})" in mata


def test_runtime_has_no_external_language_dependency() -> None:
    runtime = "\n".join(
        (ROOT / name).read_text(encoding="utf-8").lower()
        for name in ("kss_bc.ado", "kss_bc.mata")
    )
    external_invocation = re.compile(
        r"(?m)^\s*(?:shell\b|!\s*(?:python|matlab)\b|python:|rcall\b|matlab\s+-)"
    )
    assert external_invocation.search(runtime) is None


def test_package_records_internal_license_boundary() -> None:
    manifest = (ROOT / "kss_bc.pkg").read_text(encoding="utf-8").lower()
    readme = " ".join(
        (ROOT / "README.md").read_text(encoding="utf-8").lower().split()
    )
    assert "public redistribution is not authorized" in manifest
    assert "no public release license" in readme


def test_mata_uses_valid_noncolliding_profile_timers() -> None:
    runtime = (ROOT / "kss_bc.mata").read_text(encoding="utf-8")
    timer_ids = {
        int(value)
        for value in re.findall(r"timer_(?:clear|on|off|value)\((\d+)\)", runtime)
    }
    assert timer_ids == {91, 92, 93, 94, 95}
    assert all(1 <= value <= 100 for value in timer_ids)


def test_production_finite_projection_uses_mixed_coefficient_one() -> None:
    runtime = re.sub(
        r"\s+", "", (ROOT / "kss_bc.mata").read_text(encoding="utf-8")
    )
    mixed_term = "(m_constrained-p_constrained):*mixed_second"
    assert runtime.count(mixed_term) == 1
    assert f"2:*{mixed_term}" not in runtime


def test_scc_harness_is_project_scoped_and_public_only() -> None:
    scc = ROOT / "benchmarks" / "scc"
    submit = (scc / "submit_one.sh").read_text(encoding="utf-8")
    portability = (scc / "run_portability.sge").read_text(encoding="utf-8")
    job_scripts = [
        (scc / name).read_text(encoding="utf-8")
        for name in ("run_portability.sge", "run_oracle.sge", "run_scale.sge")
    ]
    assert "qsub -terse -P welfgr" in submit
    assert submit.count("-pe omp 4") == 3
    assert all("#$ -P welfgr" in script for script in job_scripts)
    assert all("#$ -pe omp 4" in script for script in job_scripts)
    executable_harness = submit + "\n" + "\n".join(job_scripts)
    assert "application/data" not in executable_harness
    assert "separations" not in executable_harness.lower()
    assert '> "$job_dir/portability.pass"' in portability
