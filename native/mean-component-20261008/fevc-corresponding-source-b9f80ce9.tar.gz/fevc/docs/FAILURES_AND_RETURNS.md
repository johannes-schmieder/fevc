# Return and failure contract

## Point-estimate matrices

The column order of every result matrix is:

1. `worker_variance`
2. `firm_variance`
3. `worker_firm_covariance`
4. `total_variance`

`e(results)` has rows `plugin`, `bias_correction`, `corrected`, and
`mcse`. Its last row equals the selected-mode diagnostic `e(mcse)`. The corrected row is also stored in `e(b)` and `e(kss)`.
The component rows and selected MCSE are available separately as `e(plugin)`, `e(correction)`,
and `e(mcse)`. Point-only and projection-only calls post no `e(V)`.
The new explicit Rust structured candidate posts `e(V)` only for
`inference(highrank)` when the joint covariance is admissible and every q0
target check passes. Its q1 route posts no Gaussian `e(V)`. The independent
exact Mata family's posting contract is unchanged.

## Outcome-centering metadata

`e(centering)` records `none`, `mean` or `corrected`; omitted `centering()`
records `mean` for both exact and JLA. `e(mcse_centering)` is
`uncentered`, `fixed observed mean`, or
`fixed observed mean and fixed centering increment`, respectively.
Both macros are posted in exact mode and with MCSE off. They describe the
centering convention, not diagnostic availability. The `corrected` row of
`e(results)` is the final leave-out estimate in every centering mode.

Centering leaves `e(plugin)` unchanged; `e(correction)` includes the selected
adjustment and `e(kss)=e(plugin)-e(correction)`. No separate increment
covariance is returned. Mean's MCSE holds its observed mean fixed. Corrected
JLA returns Mean's MCSE/covariance for the same call and holds the extra
increment fixed, excluding its numerical uncertainty. Record both centering
macros with exported diagnostics. See [CENTERING.md](CENTERING.md).

## All-point-probe numerical diagnostics

`mcse(all)` is the default. The canonical `e(mcse)` is a one-by-four SE
vector in the target order above. `e(mcse_cov_raw)` and `e(mcse_cov)` are
four-by-four raw and usable numerical covariances in the same order, including
the exact `(1,1,2)` total contraction of the three primitive components.
`e(mcse_mode)`, `e(mcse_method)`, `e(mcse_status)` and `e(mcse_available)`
record requested mode, method, typed status and usability. Exporters must save
these fields, `e(centering)`, `e(mcse_centering)`, the four SEs and raw
covariance together. These numerical
diagnostics do not create `e(V)`.

JLA all mode uses method `crossfit_if_v1`. Exact uses method `exact`, status
`exact_zero`, availability one and zero SEs/covariance. JLA statuses `ok_local`
and `ok_local_psd_adjusted` also provide usable MCSEs. Statuses
`unstable_nonpsd`, `nonsmooth_adjustment`, `nonfinite_derivative`,
`replay_failed` and `unavailable_capability` set availability zero and withhold
the SE vector and usable covariance. Material negative eigenvalues preserve
raw covariance; tolerance-level PSD cleanup is scaled to conditional plus
leverage covariance norm and receipted. Diagnostic unavailability retains
accepted points and the explicit developer conditional vector. Allocation,
corruption, invariant failure and cancellation remain command failures.

Compatibility `e(numerical_mcse)` and `e(numerical_mcse_available)` alias
`e(mcse)` and its availability. The all-probe compatibility vector is
`e(numerical_mcse_all)`; primitive three-by-three attachments remain
`e(numerical_mccov_cond)`, `e(numerical_mccov_leverage)`,
`e(numerical_mccov_all_raw)` and `e(numerical_mccov_all)`. Their primitive
order is worker variance, firm variance and worker–firm covariance.
`e(mcse_conditional)` and `e(mcse_conditional_available)` preserve the
conditional calculation for development when mode is all or conditional.
Legacy all-probe method/status returns retain their original meanings.

`e(mc_*)` returns include stage/fold counts, certified/attempted/executed replay
work, generator re-evaluations, allocation bound, PSD adjustment, residual and
sensitivity/maker margins, replay time and failed zero-based probe.
`e(numerical_replay_rhs)` stores certified phase/probe/complete-residual rows.
The status, matrix dimensions, conditional contraction, every count and
residual gate are reconciled before posting. Exact enabled MCSE returns zeros and performs
no probe/replay work. Supported projection/sampling-inference requests retain
this diagnostic for the main point estimates; no MCSE is attached to those
additional results. Their estimates, covariance, intervals, simulations and
scientific gates retain their existing contracts.

`mcse(off)` skips additional derivative/fold/replay work. Its public SE
vector, covariance matrices and last row of `e(results)` are missing, with
method `none`, status `off` and availability zero. Legacy all-probe attachments
and replay returns are absent. The developer `mcse(conditional)` selects
`e(mcse_conditional)` as `e(mcse)`, with method `conditional_target_v1` and
status `conditional` for JLA. Its full covariance is unavailable and remains
missing; no covariance is fabricated from the four SEs. Exact conditional
mode has method `exact`, status `exact_zero` and zero SEs.
`numericalmcse()` is an accepted compatibility alias; using both option names
fails before RNG.

An omitted option with an older plugin preserves the selected point backend
and posts `unavailable_capability`, with no conditional substitution. Explicit
`mcse(all)` fails with `STALE_NUMERICAL_RUNTIME` before preparation/RNG.
Automatic backend fallback retains its existing structural pre-RNG rules;
MCSE does not choose a different estimator route. See the
[original derivation](ALL_PROBE_MCSE.md) and
[current default/interface decision](MCSE_DEFAULT_INTERFACE_2026-09-30.md).

Active centering requires native centering API 1 independently of numerical
API 2. A plugin lacking it fails strict native preflight with
`RUST_BACKEND_UNAVAILABLE`; automatic routing may use Mata before
preparation/RNG under the ordinary consent rules. This capability failure
is distinct from `STALE_NUMERICAL_RUNTIME` for explicit all-probe MCSE.
Mean projection additionally requires native projection-centering API 1
(`r(projection_centering_api)`); None projection does not require it. The same
preflight/fallback rules apply when that capability is absent. Mean component
inference additionally requires `r(component_centering_api) == 1`. Existing
combined exact-Mata requests support Mean; native combined component/projection
requests remain unsupported for both Mean and None. Missing metadata is zero,
and probe cache state is cleared. Separate None component/projection
requests retain their existing capability requirements.

For active component inference, `e(inference_centering)` records `uncentered`
for None or `fixed observed mean` for Mean, and `e(inference_mean_omitted)`
records `0` or `1`, respectively. These returns are absent for point-only or
projection-only requests and cleared on failure. Mean treats the observed
retained physical-frequency working-outcome mean as a constant, omitting its
estimation uncertainty. The output and diagnostic replay state this
approximation. It is separate from numerical MCSE and from fixed-offset
nuisance uncertainty; it does not claim conditional validity given that mean.

## Opt-in inference matrices

When the joint matrix is admissible, component inference posts `e(V_primitive)` for
worker variance, firm variance, and worker--firm covariance. `e(V)` adds the
total target through the exact linear identity
`total=worker+firm+2*covariance`. `e(component_inference)` stores estimate,
standard error, and ordinary Wald endpoints. `inference(q1)` also posts
`e(q1_inference)` with the high-rank and Anderson--Rubin-style endpoints,
dominant eigenvalue and spectral share, observation-mode concentration,
rank-one covariance terms, F statistic, curvature, and critical value.

`e(q1_status)` and `e(q1_computed_targets)` describe target availability.
Status codes are 0 computed, 1 nonpositive variance, 2 singular covariance,
3 interval failure, 4 unidentified Mata mode, 5 invalid target-specific Mata
variance fit, and 6 uncertified Rust mode. Unavailable AM endpoints are
missing, never replaced by q0 intervals. Shared failures remain atomic.
See [the repair erratum](https://github.com/johannes-schmieder/fevc/blob/ffca8b5cfc0ff8c495923c00d93ca292528e57d9/fevc/docs/INFERENCE_REPAIR_ERRATUM_2026-09-04.md).

The supported explicit Rust structured modes additionally post
`e(component_spectrum)`, `e(component_trace_mcse)`,
`e(structured_variance_summary)`, `e(structured_variance_folds)`,
`e(structured_variance_cv)`, `e(component_inference_receipt)`, and
`e(component_augmentation_receipt)`. The `q=1` route also posts the raw
`e(component_q1_diagnostics)`. These report both primary and leverage-only
fits, support/extrapolation and positivity-floor behavior, ridge selection,
spectral concentration, solver receipts, Counter-V1 use, and numerical MCSE.

For the current unified V4-augmentation/V5-result development candidate,
the cross-fit matrices just listed are legacy diagnostics and are not posted.
Both observation and match deletion instead post
`e(residual_moment_diagnostics)`, `e(inference_gram_probes)`, `e(inference_gram_method)`,
`e(variance_gram_rcond)` and `e(variance_floor_share)`; cross-fit/ridge fields
are inapplicable, not zero-valued evidence. `e(inference_variance_fit)` names
the actual fitter. `e(q0_status)` codes are 0 computed, 1 nonpositive variance,
4 no positive linear influence, and 6 uncertified spectrum.
`e(inference_joint_status)` codes are 0 admissible, 1 nonpositive diagonal,
and 2 materially indefinite; `e(inference_joint_available)` is its zero-code
indicator and `e(inference_joint_posted)` records whether `e(V)` was posted.
`e(inference_computed_targets)` counts available intervals under the requested
reference. Joint rejection withholds both covariance matrices but leaves
individually computable intervals available. Missing q0 intervals are not
replaced by q1, or conversely. These are numerical availability diagnostics,
not a new coverage claim. See the
[candidate contract](INDIVIDUAL_INFERENCE_INTERFACE.md).
`e(inference_solver_columns)` reports the actual number of component-attachment
inverse-action columns; the peak and complete-residual receipts cover all of
them. They do not certify the structured conditional-variance assumption.
`e(inference_support_status)`, `e(inference_capability)`,
`e(inference_population)`, `e(inference_reference_requested)`,
`e(inference_reference_selected)`, `e(inference_q_condition)`,
`e(inference_execution_scope)`, `e(inference_variance_warning)`, and
`e(inference_reference_guarantee)` record the selected supported tuple and its
interpretation limits. Paired requested/selected inference fields reconcile
deletion, population, variance model, reference, backend, solver, and result
family. `e(result_family)` remains `generic` because the
component result is a versioned augmentation of that prepared JLA family.
For structured `q=1`, `e(component_q1_diagnostics)` also reports the raw
leave-out leading-mode variance product and the remainder-identity error.
`e(component_inference_receipt)` records the requested per-target critical
count, actual total `critical_draws`, actual `solver_columns`, and maximum
remainder-identity error. This diagnostic remains the raw absolute difference
between direct and raw-recentered remainders. The native hard gate separately
subtracts the independently computed signed normal-equation residual
contribution of both accepted solves and tests the unexplained discrepancy at
the unchanged arithmetic threshold. No displayed error is replaced by zero,
and both original solver gates remain mandatory. The raw product recenters
the leading square; the positive structured variance fit is used only for
covariance and studentization. A material unexplained identity error, fewer
than 100,000 public q=1 critical draws per computed target, or malformed V4
dimensions withholds the result. See the
[numerical certificate](NUMERICAL_ARCHITECTURE.md#native-q1-remainder-certificate).

The explicit fixed-offset match `q=0`/`q=1` attachment retains the statistical
result V4 and adds `e(component_unit_receipt)` from a separate native V1 ABI.
Its columns are `schema deletion independent_units nuisance_omitted
effective_matches largest_mass_share largest_leverage smallest_maker`;
deletion codes are 1 match and 2 observation. The independent count must
reconcile with prepared deletion units before posting. Its
Rust result identifies `Match` as the inferential unit, reports the independent
match count, effective match count, largest match-mass share, largest match
leverage, smallest finite-JLA scalar maker denominator, target-specific maximum
match influence shares, spectral diagnostics, structured-model support and
floor summaries, solver/MCSE/PSD receipts, and
`nuisance_uncertainty_conditioned_away=true`. That final flag means the
full-sample estimated control offset is held fixed: the reported
uncertainty is suggestive approximate uncertainty and omits uncertainty from
estimating the nuisance-control coefficients. The public scalars are
`e(inference_independent_units)`, `e(inference_nuisance_omitted)`,
`e(inference_effective_matches)`, `e(inference_largest_mass_share)`,
`e(inference_largest_leverage)`, and `e(inference_smallest_maker)`.
Effective count is `(sum F_g)^2 / sum F_g^2`, a regression-mass concentration
diagnostic, not an estimated degrees-of-freedom adjustment. Observation
requests receive the unit receipt with match-specific entries zero and do not
post match-specific scalars. The requested/selected nuisance metadata and
`e(inference_offset_warning)` make the fixed-offset approximation explicit.
For match `q=1`, the same Rust result additionally retains the raw
leave-match leading recenter, leading and remainder covariance, direct
remainder-identity error, curvature, critical value, interval endpoints,
remainder spectral share, maximum leading-mode match weight, and maximum
remainder-influence share for each target. Singular or materially indefinite
joint covariance or an unidentified/nonconverged mode withholds that target's
q1 interval. A material unexplained remainder identity error under the
certificate above, nonestimable deletion,
malformed shared state, resource rejection, or interruption withholds the
atomic result. These diagnostics do not assert that
a computed target has a one-mode, diffuse-remainder asymptotic regime.

Fixed-effect projections post `e(projection_b)`, `e(projection_V)`,
`e(projection_V_naive)`, and `e(projection_results)`. They do not populate the
component `e(V)` unless component inference is requested in the same call.
`e(inference_diagnostics)` records simulations, seed, bins, confidence level,
component and projection PSD cleanups, component and projection variance-proxy
ranges, mover/stayer row counts, and the count of tiny fitted variances set to zero. See
[`INFERENCE.md`](INFERENCE.md) for definitions and limitations.

Projection metadata records the effective deletion mode, mover/stayer
partition, exact or sparse-JLA route, and the fixed-effect normalization. The
reported slopes are invariant to equivalent worker/firm location shifts. The
automatic constant is explicitly normalization-dependent under the last-
retained-firm-zero convention.

`e(decomposition)` is the applied additive view. Its rows are
`worker_variance`, `firm_variance`, `sorting_2covariance`, and
`total_worker_firm`; its columns are `plugin`, `bias_correction`, `corrected`,
`plugin_share_outcome`, `corrected_share_outcome`,
`plugin_share_worker_firm`, and `corrected_share_worker_firm`. Unlike the raw
covariance in the established matrices, the sorting row is twice the
worker--firm covariance, so the first three rows add to the fourth. Shares are
stored as proportions and are missing when their denominator is nonpositive.
Negative component contributions remain valid when the denominator is
positive.

## Main metadata

The command records the requested, complete, initial-component, mover-input,
retained stored-row, and physical-copy counts. It also records worker and firm
levels, parameters, deletion units, target mass, maximum leverage, weighted
RSS, dense-information reciprocal conditioning when available, the
matrix-free Schur-diagonal ratio, the exact low-dimensional control-Schur
reciprocal conditioning, inverse/solver residuals, solver iterations, probes,
batch, seed, and tolerances. Timing scalars separately report graph selection,
fit, matrix-free setup, Schur actions, preconditioner
applications, PCG, leverage probes, target probes, the combined correction,
and the solver backend. `e(preconditioner_seconds)` remains a compatibility
alias for `e(setup_seconds)`. Under API 18, setup and fit are disjoint; exact
mode reports zero for iterative fields.
Profiling borrows only unused caller timers and releases them on every exit.
If timers are unavailable, estimation continues: affected timing fields and
totals are missing, while unexecuted phases retain their structural zeros and
independently measured native timings remain available. Timer availability
never changes solver selection or numerical acceptance.
JLA additionally records RHS-equivalent action counts, physical matrix-batch
counts, and `e(solver_rhs_diagnostics)` with stage, batch start, RHS index,
iterations, freshly recomputed complete relative residual, and convergence.
It also posts `e(route_diagnostics)`, `e(preconditioner_requested)`,
`e(preconditioner_selected)`, `e(routing_reason)`, `e(fallback_status)`, and
`e(fallback_message)`. `e(route_api)` identifies structural routing.
`e(memory_budget_supplied)` records whether `memory_gib()` was supplied;
`e(memory_gib)` is its value in GiB or missing when omitted. The policy macro
`e(memory_check)` is `warn` by default, `error`, or `off`; a policy alone
creates no budget. `e(memory_forecast_bytes)` is the expected peak within
`e(memory_forecast_scope)`. `e(memory_admission_forecast_bytes)` adds
conditional refinement reserve and is the value compared with an explicit
budget. `e(memory_conditional_reserve_bytes)` is their difference, and
`e(memory_forecast_model)` is currently 1. These returns follow successful
completion; they are not a separate pre-execution forecast API. Native direct
allocation payload is distinct from total process RSS. Mata JLA includes
modeled Stata working data. See [MEMORY.md](MEMORY.md).

`e(batch_requested)` preserves `auto` or the caller's integer, and `e(batch)`
is the selected numeric batch. `e(batch_routing_reason)`,
`e(batch_column_forecast_bytes)`, `e(batch_scratch_forecast_bytes)`, and
`e(batch_memory_budget_bytes)` identify the deterministic choice. The last is
a route-specific planning allowance, not necessarily the whole budget; it is
missing without a budget. Omission disables memory-based batch, concurrency
and route adjustments. Explicit batches are preserved under every policy.
Exact mode labels routing not applicable.
CMG routes expose the fine hybrid vertex/edge counts, hierarchy level count,
and bounded terminal vertex count in `e(route_hybrid_vertices)`,
`e(route_hybrid_edges)`, `e(route_hierarchy_levels)`, and
`e(route_terminal_vertices)`.
Forced CMG never reports a diagonal fallback. Automatic fallback retains the
typed structural CMG boundary that caused diagonal selection. Historical
pilot matrices, pilot iteration scalars, and projected-work ratios are not
part of the active return contract.

`e(full_parameters)` is the dimension of the preliminary full design.
`e(correction_parameters)` is the dimension of the design used for the
leave-out correction. Under `nuisance(fixedoffset)`, the latter therefore
counts the pure two-way working design after the preliminary full joint fit;
under joint mode the two values agree. `e(parameters)` remains a compatibility
alias for `e(correction_parameters)`.

The retained-sample descriptive moments are
`e(target_outcome_variance)`, `e(regression_outcome_variance)`,
`e(residual_variance)`, `e(full_model_explained_variance)`, and
`e(full_model_explained_share)`. The first uses the KSS target mass. The second
uses literal frequency mass; the residual variance is
`e(weighted_rss)/e(N_physical)`, and their difference is the descriptive
full-model explained variance. This full-model quantity includes controls and
is not a KSS correction of control components. When `targetweight()` differs
from frequency weights, the target and regression moments describe different
populations and are not presented as one additive decomposition.

`e(information_rcond)` is populated only by the dense exact backend.
`e(preconditioner_ratio)` is the minimum-to-maximum Schur-diagonal ratio used
by JLA and is not mislabeled as an information-matrix condition number.
`e(control_schur_rcond)` reports the exact residualized-control Schur
reciprocal condition number prepared by the matrix-free JLA backend. Dense
exact joint mode reports the reciprocal conditioning of its complete
identified information matrix in `e(information_rcond)`. Dense exact fixed
offset reports the minimum reciprocal conditioning of the preliminary full
joint fit and the pure-FE working fit, because both factorizations authorize
the returned conditional calculation.
`e(deletion_rank_gap)` is the probe-independent lower bound from the
within-cell full-fit and deletion-rank certificate. It is populated for every
accepted JLA calculation with controls, including fixed offset. A positive
value certifies that the control block retains rank in the full fit and after
every declared deletion at the registered numerical margin, conditional on
the graph certificate for the FE block. The reported bound already subtracts
the measured whitening residual and a rounding allowance and is no larger
than either the trace lower bound or the smallest directly factored
deleted-scatter eigenvalue.

Graph fields report the initial deletion-unit edge count, retained edge count,
articulation workers removed, largest number of components encountered,
insufficient workers removed, bridge units and rows removed, bridge passes,
total fixed-point passes, and the final bridge count. A successful match
calculation requires `e(graph_final_bridge_units)==0`. String metadata names the model, correction,
algorithm, deletion unit, nuisance convention, sample-selection convention,
target population, weight conventions, numerical error label, and the
requested inference method or its absence.

## Successful status

`e(status)` is `KSS_POINT_ESTIMATES_ONLY` for point-only general and exact engines
and `KSS_SCALE_EXPERIMENTAL_POINT_ESTIMATES` for the compressed engine. Both
mean that the requested finite point calculation passed its registered
scientific, numerical, memory-policy/reconciliation, and restoration gates. The latter name
is an engine-development label, not a scale qualification. Neither status
means that the application's independence assumptions were verified.

Accepted opt-in requests instead use `KSS_HIGHRANK_INFERENCE`,
`KSS_Q1_INFERENCE`, or `KSS_PROJECTION_INFERENCE`, with combined component and
projection variants when both are requested. These statuses mean that the
finite inference calculation passed the registered numerical and capability
gates; they do not verify the sampling assumptions in an application.
For Mean, read these statuses together with `e(inference_centering)` and
`e(inference_mean_omitted)`; successful calculation does not validate the
omitted-mean-uncertainty approximation.
The explicitly selected Rust structured modes use
`FEVC_STRUCTURED_Q0_INFERENCE` and `FEVC_STRUCTURED_Q1_INFERENCE`. The FEVC
prefix is intentional: these are pragmatic structured-variance extensions,
not the paper's unrestricted-heteroskedastic KSS variance-product estimator.

## Withholding statuses

Before exiting a recognized failure path, the command sets `e(status)` to
`WITHHELD` and records a typed `e(withholding_status)`. It also records the
technical detail in `e(withholding_detail)`, an applied explanation in
`e(withholding_reason)`, and concrete next steps in
`e(withholding_suggestion)`. The displayed failure block links to the help
file's troubleshooting section. These suggestions explain available remedies
but never silently alter the deletion assumption, tolerance, sample, or
estimand. The catalog includes:

- `INVALID_CENTERING` (return code 198) for an unknown centering mode;
- `CENTERING_INFERENCE_UNSUPPORTED` (return code 498) for Corrected with
  active component `inference()` or `project()`, rejected before estimator RNG.
  Mean (the default) and None are permitted on existing supported tuples,
  including combined exact-Mata requests; native combined component/projection
  requests remain unsupported for Mean and None;
- `INVALID_FREQUENCY`, `PHYSICAL_TOTAL_LIMIT` when the exact literal count
  exceeds `2^53`, and `INVALID_TARGET_WEIGHT`;
- `INVALID_DEPVAR`, `INVALID_CONTROLS`, `INVALID_INPUT`, `NONFINITE_INPUT`,
  `INVALID_TUNING`, `INVALID_TOLERANCE`, `INVALID_NUISANCE`, and
  `INVALID_STAYER_CONVENTION`, plus `INVALID_PRECONDITIONER` and
  `INVALID_MEMORY_ENVELOPE`, `INVALID_WALL_ENVELOPE`, and `INVALID_ENGINE`;
- `UNSUPPORTED_ALGORITHM`, `UNSUPPORTED_DELETION`,
  `UNSUPPORTED_DELETION_ID`, and `UNSUPPORTED_STAYER_CONVENTION`;
- `INVALID_INFERENCE`, `INVALID_INFERENCE_TUNING`,
  `INVALID_INFERENCE_MODEL`, and `INFERENCE_MODEL_WITHOUT_INFERENCE`,
  `INVALID_PROJECTION_EFFECT`, `INVALID_PROJECTION_WEIGHT`, and
  `PROJECTION_OPTIONS_INCOMPLETE` for malformed inference requests;
- `INFERENCE_DELETION_UNSUPPORTED`, `INFERENCE_STAYER_UNSUPPORTED`,
  `INFERENCE_FREQUENCY_UNSUPPORTED`, `JLA_INFERENCE_UNSUPPORTED`,
  `RUST_INFERENCE_UNSUPPORTED`, and `COUNTER_INFERENCE_UNSUPPORTED` for
  component requests outside the exact-observation Mata capability, or a
  projection tuple outside the separately documented block capability;
- `INFERENCE_MODEL_UNSUPPORTED`, `STRUCTURED_INFERENCE_TUPLE_REQUIRED`,
  `STRUCTURED_FREQUENCY_UNSUPPORTED`, and
  `COMPONENT_PROJECTION_COMBINATION_UNSUPPORTED` for a structured request
  outside its supported explicit tuple; unknown model tokens instead fail
  as `INVALID_INFERENCE_MODEL`;
- `NEGATIVE_INFERENCE_VARIANCE`, `INFERENCE_VARIANCE_INVALID`,
  `INFERENCE_COVARIANCE_NOT_PSD`, `INFERENCE_EIGEN_FAILURE`,
  `INFERENCE_INTERVAL_FAILED`, and
  `Q1_COVARIANCE_INVALID` for nonfinite, nonpositive, singular, or materially
  indefinite component inference;
- `PROJECTION_DESIGN_SINGULAR` and `PROJECTION_COVARIANCE_INVALID` for an
  unidentified projection or an invalid KSS covariance;
- `STALE_INFERENCE_RUNTIME`, `INFERENCE_RUNTIME_NOT_FOUND`,
  `INVALID_INFERENCE_RUNTIME`, and `INFERENCE_RUNTIME_FAILED` for an absent,
  incompatible, or unexpectedly stopped inference runtime;
- `INVALID_IDENTIFIER`, `INVALID_PROBE_ORDER`, `CROSS_COORDINATE_MATCH`, and
  `MATCH_INPUT_MISSING`;
- `NO_USABLE_OBSERVATIONS`, `NO_MOVER_SAMPLE`, and
  `NO_LEAVEOUT_COMPONENT`;
- `AMBIGUOUS_LARGEST_COMPONENT` when the registered component ranking ties
  and therefore has no ID-relabeling-invariant winner;
- `AMBIGUOUS_CONTROL_BASIS` when controlled exact has the same unresolved
  numerical basis problem, more than 32 controls are requested, the dimensioned
  whitening/anchor/span envelope cannot certify a pivot, a pivot score lies
  within its cutoff envelope, or full/deletion conditioning cannot propagate
  the canonical basis within the registered `1e-8` ceiling;
- `SINGULAR_INFORMATION`, `SINGULAR_NUISANCE_BLOCK`, and
  `NONESTIMABLE_DELETION`;
- `INVERSE_FORWARD_ERROR_FAILED` when a dense information inverse is too
  ill-conditioned relative to its recomputed residual for a fail-closed
  Woodbury rank decision;
- `INVERSE_RESIDUAL_FAILED`, `BLOCK_INVERSE_FAILED`, and
  `CONTROL_SCHUR_RESIDUAL_FAILED` when a recomputed dense, block, or
  low-dimensional inverse residual fails its registered numerical gate;
- `UNVERIFIED_DELETION_RANK` when a JLA control design, including a fixed-offset
  full fit, does not satisfy the deterministic sufficient certificate and
  therefore requires exact verification or revised controls;
- `EXACT_SIZE_LIMIT` and `BLOCK_SIZE_LIMIT`;
- `PHYSICAL_COPY_LIMIT` when any selected JLA route would allocate more
  literal-copy state than `physical_limit()` authorizes;
- `RESOURCE_ADMISSION_FAILED` or `GENERIC_RESOURCE_ADMISSION_FAILED` for
  over-budget allocation forecasts only when an explicit `memory_gib()` is
  paired with `memorycheck(error)`;
- `SOLVER_MEMORY_LIMIT` when the solver admission forecast exceeds that
  explicit strict budget before estimator RNG. Preparation and hierarchy
  construction may already have run. With no budget, `warn`, or `off`, an
  over-budget forecast alone does not fail the public command. Actual
  allocation failures, overflow and inconsistent memory receipts remain
  errors. Legacy internal callers retain their older strict semantics;
- percentage headroom and wall forecasts do not independently produce a
  memory rejection; conditional refinement storage is included in the
  admission forecast and is not percentage headroom;
- `PCG_BREAKDOWN`, `PCG_NONCONVERGENCE`, and
  `SOLVER_RESIDUAL_FAILED`;
- `FORCED_CMG_FAILED` when an explicitly requested CMG route fails setup or
  execution;
- typed CMG preflight, memory, hierarchy, construction, or application
  failures. Under `preconditioner(auto)`, only structural pre-RNG boundaries
  may produce `FALLBACK_TO_DIAGONAL`; `preconditioner(cmg)` fails closed and
  preserves the original status and message;
- `JLA_CONSTRAINT_FAILED`, `JLA_MOMENT_FAILED`, and
  `JLA_INVERSE_FAILED`;
- `STALE_MATA_RUNTIME`, `STALE_CMG_RUNTIME`, `STALE_SOLVER_RUNTIME`,
  `STALE_RNG_RUNTIME`, `STALE_RESOURCE_RUNTIME`,
  `INVALID_MATA_RUNTIME`, `INVALID_GRAPH_RUNTIME`, `INVALID_CMG_RUNTIME`,
  `INVALID_RNG_RUNTIME`, `INVALID_RESOURCE_RUNTIME`, and
  `INVALID_SOLVER_RUNTIME` when an installed runtime does not match the ado
  caller, plus `RNG_RUNTIME_UNREGISTERED` when JLA is requested on an
  unregistered Stata runtime. Exact estimation does not require that RNG
  registration;
- `INVALID_GRAPH_INPUT`, `GRAPH_ITERATION_FAILED`,
  `GRAPH_BRIDGE_CERTIFICATE_FAILED`, `GRAPH_RUNTIME_FAILED`, and
  `MATA_RUNTIME_FAILED` for typed graph or backend execution failures;
- `NONFINITE_FIT`, `NONFINITE_LEVERAGE`, `NONFINITE_CORRECTION`, and
  `NONFINITE_CORRECTED_TARGET` when the final finite component subtraction
  overflows; and
- `NO_MOVER_SAMPLE` when explicit observation `stayers(movers)` excludes every
  complete-case worker. `stayers(both)` is accepted and is the default in both
  deletion modes. Mixed match/stayer Rust requests still reject unsupported
  explicit probe-order and wall-time options before estimator RNG; observation
  deletion does not use that mixed attachment.

The command never repairs these states through an undisclosed ridge,
different component, changed deletion unit, reduced probe count, or loosened
tolerance.

The combined match-deletion default is deliberately labelled mixed deletion: its mover
correction follows declared match blocks, while its stayer correction is not
match-robust. `stayers(movers)` is the explicit opt-out when a uniformly
match-deleted target is required.

Explicit `inferencegramprobes()` outside the supported structured Rust component
tuple returns `INFERENCE_GRAM_TUPLE_REQUIRED` before estimator RNG. A noninteger
or count outside [512,2147483647] returns `INVALID_INFERENCE_TUNING`. Omitted
precision is 2048. Current Stata requires component interface 4; a stale plugin
returns `COMPONENT_NATIVE_INTERFACE_REQUIRED`. The result count must equal
the requested/planned count; a corrupted receipt fails atomically.

## Control-basis certification (API 23)

`AMBIGUOUS_CONTROL_BASIS` describes an unavailable numerical certificate, not
demonstrated model singularity. This includes a control-Gram inverse-residual
failure in both backends. Its diagnostic detail retains
`INVERSE_RESIDUAL_FAILED`, `control_basis_gram`, the measured residual and gate.
An actual singular Gram retains its existing singularity status. Inspect scales
and near dependencies and consider a scientifically equivalent representation;
the command does not change the sample, controls or numerical tolerances.
See [the complete numerical contract](CONTROL_BASIS_CERTIFICATION.md).

## API 24 control-preparation memory and interruption

The 256-lane control kernel is checked against its allocation forecast before
Gram construction when `memorycheck(error)` and an explicit budget apply.
Insufficient control-phase memory returns `RESOURCE_LIMIT`; the generic route
may reject earlier through its existing resource-admission status. Warning,
off and omitted-budget behavior is unchanged. A user interrupt during control
preparation returns Stata code 1, clears estimates, and restores ordinary
caller state; it is not `MATA_RUNTIME_FAILED` or control-basis ambiguity.

`RUST_PARALLEL_DELETION_UNSUPPORTED` means the complete-case supplied match
partition has distinct blocks at one coefficient cell and the loaded plugin
lacks deletion-unit mover readiness (bit 15). Update the plugin to use Rust. Automatic point routing records
`e(backend_fallback)=1`, the same reason, and phase `preflight`, and uses Mata.
Strict Rust or Counter requests withhold before native preparation/RNG.
Match-mode `e(N_stayers)`/`e(N_stayer_rows)` count original one-block histories;
observation-mode counts still use original one-firm histories.

## Candidate control-span failure diagnostics

The generic Rust control-span certificate emits `FEVC_CONTROL_CERT_V1` in
`e(withholding_detail)` and sets `e(status)=WITHHELD`. The exact native phase
is `e(native_failure_phase)`; `e(native_error_phase)` retains its existing
outer-operation meaning. `e(control_certificate_failure)` is a failure-only
row with columns `N controls units bound transform_norm conditioning propagated
ceiling original_residual canonical_bound accumulated_bound inconclusive`.
The selected span bound is an absolute weighted Frobenius residual; the
conditioning value is the certified least eigenvalue in the reported phase's
whitened coordinates. The propagated field is the relative information-inverse
bound, not a measured target error or Monte Carlo error. Missing propagated
values mean nonfinite/unavailable certification. The final column is one.
The schema, selected bound and prepared-population label are also returned as
`e(control_certificate_schema)`, `e(control_certificate_selected)` and
`e(control_certificate_population)`. Request population remains in `e(stayers)`.
The full-phase original residual is the maximum original-system control
projection residual; the deletion-phase value is the original-system full-fit
residual. Before a quantity is computed it is unavailable, never assumed zero.

Errors that occur before this certificate retain their typed code, exact phase
and existing residual/rank detail. An inconclusive span certificate is
`AMBIGUOUS_CONTROL_BASIS`, not evidence of structural nonidentification.
Failure receipts contain no coefficient vectors, success matrices or `e(sample)`.
Error-string retrieval bypasses the progress wrapper to preserve its Stata
macro scope under normal, verbose and quiet execution.
