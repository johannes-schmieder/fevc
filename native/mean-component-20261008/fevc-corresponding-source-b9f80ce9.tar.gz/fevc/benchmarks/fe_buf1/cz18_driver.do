version 18.0
clear all
set more off
set varabbrev off

args source_root input_dta output_csv source_label source_commit pair_order round
if !ustrregexm("`source_commit'", "^[0-9a-f]{40}$") |              ///
    !inlist("`source_label'", "baseline", "candidate") |          ///
    !inlist("`pair_order'", "ab", "ba") |                         ///
    missing(real("`round'")) | !inlist(real("`round'"), 1, 2, 3) {
    di as error "invalid FE-BUF-1 CZ18 benchmark arguments"
    exit 198
}
confirm file `"`source_root'/fevc/fevc.ado"'
confirm file `"`input_dta'"'
adopath ++ `"`source_root'/fevc"'
capture set processors 4
if _rc | c(processors) != 4 {
    di as error "Stata/MP did not honor the four-processor request"
    exit 459
}

local input_sha "1748ca2a6a46f248e05c0329407e7e7708ec7628c1ffce5f0e06ee264bdf0575"
local probes 20
local seed 8675309
local load_started = clock(c(current_date)+" "+c(current_time), "DMY hms")
quietly use `"`input_dta'"', clear
local load_finished = clock(c(current_date)+" "+c(current_time), "DMY hms")
local load_seconds = (`load_finished'-`load_started')/1000
confirm numeric variable worker firm y_minus_xb observation_key
isid observation_key
quietly count
assert r(N) == 8201888

quietly _datasignature
local data_signature `"`r(datasignature)'"'
set rng default
set seed 20260819
set sortseed 20260819
local rng_before `"`c(rngstate)'"'
local sort_rng_before `"`c(sortrngstate)'"'

local command_started = clock(c(current_date)+" "+c(current_time), "DMY hms")
quietly fevc y_minus_xb, worker(worker) firm(firm)             ///
    deletion(match) probeorder(observation_key) algorithm(jla)       ///
    engine(auto) preconditioner(auto) memory_gib(56) wallseconds(1680) ///
    probes(`probes') batch(auto) seed(`seed') tolerance(1e-10)       ///
    maxiter(20000) nodisplay
local command_finished = clock(c(current_date)+" "+c(current_time), "DMY hms")
local command_seconds = (`command_finished'-`command_started')/1000

assert "`e(status)'" == "KSS_SCALE_EXPERIMENTAL_POINT_ESTIMATES"
assert "`e(algorithm)'" == "jla"
assert "`e(engine_selected)'" == "compressed"
assert "`e(preconditioner_selected)'" == "CMG"
assert e(complete_residual_max) <= e(residual_acceptance_tolerance)
assert e(target_identity_residual) <= 1e-12
assert "`e(fe_buffer_profile_schema)'" == "FE-BUF-PERF-V1"
matrix one_result = e(results)
matrix fe_profile = e(fe_buffer_profile)
assert rowsof(one_result) == 4 & colsof(one_result) == 4
assert rowsof(fe_profile) == 1 & colsof(fe_profile) == 10

tempvar in_sample
generate byte `in_sample' = e(sample)
quietly count if `in_sample'
local sample_count = r(N)
drop `in_sample'
quietly _datasignature
local data_restored = (`"`r(datasignature)'"' == `"`data_signature'"')
local rng_restored = (`"`c(rngstate)'"' == `"`rng_before'"')
local sort_rng_restored = (`"`c(sortrngstate)'"' == `"`sort_rng_before'"')
assert `data_restored' == 1
assert `rng_restored' == 1
assert `sort_rng_restored' == 1
assert e(life_sample_restored) == 1

matrix receipt = J(1,66,.)
matrix colnames receipt = run load_s command_s selection_s graph_s         ///
    compression_s transition_s work_s restore_s setup_s fit_s leverage_s   ///
    target_s correction_s rng_s schur_s precond_s pcg_s iterations         ///
    schur_actions schur_batches precond_apps precond_batches max_residual   ///
    acceptance peak_bytes work_bytes n_rows n_retained cells units strata  ///
    workers firms identity_residual sample_count life_sample_restored       ///
    data_restored rng_restored sort_rng_restored                            ///
    r11 r21 r31 r41 r12 r22 r32 r42 r13 r23 r33 r43 r14 r24 r34 r44      ///
    fe_applicable fe_workspace_builds fe_buffered_batches fe_legacy_batches ///
    fe_buffered_columns fe_legacy_columns fe_fallback_batches fe_max_width  ///
    fe_workspace_bytes fe_avoided_bytes
matrix receipt[1,1] = (real("`round'"),`load_seconds',`command_seconds',   ///
    e(sample_selection_seconds),e(graph_seconds),e(compression_seconds),    ///
    e(life_transition_seconds),e(life_work_seconds),e(life_restore_seconds), ///
    e(setup_seconds),e(fit_seconds),e(leverage_seconds),e(target_seconds),  ///
    e(correction_seconds),e(rng_seconds),e(schur_seconds),                  ///
    e(preconditioner_apply_seconds),e(pcg_seconds),e(solver_iterations),    ///
    e(solver_schur_actions),e(solver_schur_batches),                       ///
    e(solver_precond_applications),e(solver_precond_batches),              ///
    e(solver_max_residual),e(residual_acceptance_tolerance),               ///
    e(resource_peak_bytes),e(life_mem_work_bytes),e(N_stored),             ///
    e(N_retained),e(coefficient_cells),e(deletion_units),e(target_strata), ///
    e(worker_levels),e(firm_levels),e(target_identity_residual),            ///
    `sample_count',e(life_sample_restored),`data_restored',                 ///
    `rng_restored',`sort_rng_restored')
matrix receipt[1,41] = (vec(one_result)',fe_profile)

local route `e(preconditioner_selected)'
local engine `e(engine_selected)'
local selected_batch = e(batch)
local status `e(status)'
clear
svmat double receipt, names(col)
generate str12 source_label = "`source_label'"
generate str40 source_commit = "`source_commit'"
generate str2 pair_order = "`pair_order'"
generate str64 input_sha256 = "`input_sha'"
generate byte processors = c(processors)
generate int probes = `probes'
generate long seed = `seed'
generate int selected_batch = `selected_batch'
generate str12 route = "`route'"
generate str12 engine = "`engine'"
generate str48 estimator_status = "`status'"
order source_label source_commit pair_order run processors probes seed    ///
    input_sha256 selected_batch route engine estimator_status
export delimited using `"`output_csv'"', replace

di as result "KSS_FE_BUF1_CZ18_PASS `source_label' `source_commit' `pair_order' R`round'"
exit 0
