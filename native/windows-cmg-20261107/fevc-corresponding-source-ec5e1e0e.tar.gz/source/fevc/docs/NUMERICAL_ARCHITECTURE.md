# Numerical architecture

## Optimization III scale representation

The compressed production modules compile with `matalnum off` and keep
`matastrict on`; explicit quad operations remain deliberate. Canonical
worker, firm, cell, deletion-unit, and target-stratum identities are exact
numeric dense ranks. No persistent string key or unverified hash enters the
RNG contract. The runtime stores the coefficient-cell payload once, plus
worker-major and firm-major order/panel vectors. A compact FE view dispatches
transpose, prediction, Schur, diagonal, and reconstruction operations to that
payload instead of building the generic cell design again.

Cancellation-sensitive preprocessing uses a deterministic tiled Neumaier
reducer with bounded `65,536 x active-RHS` scratch. Exact nonnegative integer
mass totals use native segmented sums only after checking their registered
sum is below `2^53`. Repeated FE operator traversal uses native segmented
aggregation and relies on the unchanged complete original-system residual as
the acceptance certificate. The ado reuses canonical graph maps through
pruning and deletion construction, then releases row mappings at the existing
disk-backed lifecycle boundary.

The explicit persistent-cell inventory is `8*(9*C + 3*W + 4*F)` bytes:
seven canonical payload columns, two cell-order vectors, and the worker/firm
panels and masses. Deletion units and target strata each use four numeric
columns (`32*G` and `32*S` bytes). Routed quotient work vectors add
`8*5*(W+F)` bytes to the external operator view. Phase scratch, hierarchy,
certificates, transition high-water, restoration, and raw Stata data remain
separate model families; a compressed-engine forecast is not an end-to-end
raw-input forecast.

The Optimization III scale ladder identifies a route discontinuity at four
cells per worker. At 625,000 workers, the three-cell case builds a 15,625-
vertex hybrid hierarchy in 35.478 seconds, while the four-cell case retains
640,625 hybrid vertices and spends 8,755.873 seconds in setup. The latter
still converges in 15 iterations with a passing complete residual, so the
dominant problem is hierarchy construction rather than repeated-RHS PCG.
The KSS Matlab implementation completes the paired four-cell task in
84.951 seconds and converges, providing an independent algorithmic benchmark
for a future firm-Schur/degree-four CMG setup specialization. Optimization III
does not change routing semantics or introduce that new hierarchy algorithm;
its target model treats this measured discontinuity explicitly and the final
report records the resulting feasibility boundary.

## Sample pipeline

The ado layer freezes the requested variables, validates frequency and target
weights, expands factor-variable controls, and encodes string or numeric IDs
densely. Match deletion rejects incomplete requested rows because silently
changing one declared block would change the dependence contract.
Observation deletion uses a reproducible complete-case sample for outcomes
and regressors. Only factor-variable terms carrying Stata's explicit omitted
metadata are removed during expansion. An ordinary numeric column remains in
the requested design even when it is identically zero or collinear, so the
backend rank gates withhold the singular model rather than silently repairing
it. Before dispatch, the caller checks the API, version, and
semantic build token of any loaded Mata runtime. A stale same-level runtime is
withheld rather than silently used.
It also accumulates the literal frequency total with an exact remaining-
capacity test and withholds `PHYSICAL_TOTAL_LIMIT` above `2^53`. Consequently,
all later nonnegative integer component and observation counts are exactly
represented in binary64.

The match graph stage uses the following deterministic fixed point:

1. select the largest connected worker--firm component, ranked first by firm
   count and then by physical mass;
2. in match mode, restrict every headline target and the fitted model to
   workers observed at more than one fitted firm;
3. find worker articulation vertices with an iterative, nonrecursive Tarjan
   traversal;
4. remove those workers and insufficient histories, select the largest
   resulting component, and repeat;
5. encode each distinct deletion ID as one multigraph edge, preserving
   parallel deletion IDs at a common worker--firm coordinate;
6. find deletion-unit bridges with an iterative Tarjan traversal, remove the
   complete bridge set simultaneously, and repeat all earlier stages; and
7. require a final zero-bridge certificate before encoding the quotient.

Observation deletion retains the API 17 graph path unchanged. Its deletion
unit is still one literal physical copy.

If two components tie on both registered ranking quantities at any selection
step, there is no ID-relabeling-invariant winner. The command withholds with
`AMBIGUOUS_LARGEST_COMPONENT` instead of using encoded identifiers as a
tie-breaker.

The command reports every stage through sample counts and graph diagnostics.
The exact block gate or deterministic joint-control certificate remains
authoritative for deletion estimability when controls add rank restrictions
not visible in the graph.

## Dense exact backend

The exact backend builds all worker indicators, all but one firm indicator,
and the requested control columns. It equilibrates the information matrix,
checks its spectrum, factors it once, and applies Woodbury block identities.
It relies on weighted information rank and deleted-information gates, not a
stored-row-count surrogate; literal copies can supply residual degrees of
freedom even when the stored-row count equals the parameter count.
It is deterministic and seed independent. `exact_limit()` and
`blocksize_limit()` prevent unregistered dense allocations. The backend
compares its inverse residual with reciprocal conditioning to obtain a
forward-error proxy. Whenever a Woodbury residual-maker eigenvalue lies
inside ten times that proxy, it also forms and factors the deleted information
matrix directly. A failed direct factor withholds the entire calculation.
The term exact distinguishes deterministic algebra from JLA; it does not mean
exact arithmetic.

API 18 factors every match projection as \(UU'\). It checks and solves the
positive-definite observation-space maker \(I-UU'\) when stored rows are the
smaller dimension. Otherwise it checks the reduced maker \(I-U'U\) and applies

\[
(I-UU')^{-1}R=R+U(I-U'U)^{-1}U'R.
\]

The action is then substituted into the unchanged exact correction. The
implementation recomputes the complete observation-space residual for every
right-hand side and includes its maximum in the posted inverse residual. It
therefore avoids a large observation-block eigendecomposition without using a
weaker acceptance gate.

## Matrix-free two-way solve

For the pure two-way part, the information matrix is

\[
H=\begin{pmatrix}
D'WD&D'WF\\
F'WD&F'WF
\end{pmatrix}.
\]

`D'WD` is diagonal. Eliminating worker coordinates produces the singular
firm-mobility Laplacian

\[
S_F=F'WF-F'WD(D'WD)^{-1}D'WF.
\]

Mata applies `S_F` with grouped sums and solves it by diagonally
preconditioned conjugate gradients on the zero-sum quotient. The right-hand
side includes all firm equations, every iterate and preconditioned residual is
projected onto the quotient, and no encoded firm is privileged during the
iterative path. Only after convergence does the implementation subtract the
last firm's coefficient to return the public all-worker/all-but-one-firm
coordinate representation. It then reconstructs the worker coordinates.
Every accepted solve recomputes every worker and every firm normal-equation
residual under the original full two-way operator. The reported solver
residual is the maximum across
the fit, control preparation, leverage probes, target probes, and every
right-hand-side column within a batch. No large or well-scaled neighboring
column can mask a failed column through a single Frobenius ratio. In match
mode the maximum also includes every small residual-maker inverse residual.

The algebraic JLA derivation refers to the exact orthogonal FE projection.
Matrix-free inverse actions are numerical approximations to that projection,
and each nonzero right-hand side is accepted only when its scale-relative
recomputed full-system residual is at most
`max(1e-11,10*tolerance())`. The automatic no-control `CMG_FULL_V2` route
instead registers `max(1e-11,10*max(fit,probe))` phase tolerances and posts
that gate as `e(residual_acceptance_tolerance)`; all-probe replay reuses the
route and is validated against the same gate. Its warm-start refinement stops
on `||r|| <= factor*gate*||b||` rather than CMG's operator-scaled relative
test, which can stall above the gate when `||A|| ||x||` dominates `||b||`.
Solver error is reported separately from probe MCSE. The implementation does not infer a forward-error or
uniform-theorem bound from a residual alone; dense overlap tests and SCC
qualification are numerical evidence at the registered tolerance.

For Rust's generic diagonal route, a converged reduced solve that fails the
complete-system gate receives at most three residual corrections through the
same prepared operator and diagonal preconditioner. Correction PCG tolerances
are 0.1, 0.01 and 0.001 times the requested phase tolerance; the original
acceptance gate is unchanged. Only correction right-hand sides are projected
onto the worker--firm quotient, and each accumulated answer is checked against
all original equations. Passing columns receive no correction. Work counters
include correction solves, while logical RHS and RNG counts remain unchanged;
the reduced-residual diagnostic stays relative to the original reduced RHS.
Exhaustion remains a hard `FULL_RESIDUAL_FAILED` error. The memory forecast
includes the extra scalar correction workspace beside a retained batch.

The command profiles graph selection, fit, Schur-diagonal setup, Schur
actions, preconditioner applications, PCG, leverage probes, target probes, and
the combined correction. API 18 measures setup and fit with disjoint timers
and posts setup as `e(setup_seconds)`; `e(preconditioner_seconds)` remains its
compatibility alias. Exact mode reports zero for iterative-solver fields. JLA posts per-RHS
stage/batch/iteration/complete-residual diagnostics plus RHS-equivalent action
counts and physical matrix-batch counts.

Joint controls use an exact low-dimensional FWL Schur complement. The
matrix-free service accepts scalar or multiple right-hand sides. Multiple
columns use independent scalar PCG recurrences in lockstep: a single matrix
Schur action serves all active columns at each iteration, inactive columns are
exactly zero, and every column retains its own curvature, stopping, iteration,
and full-residual gate. Every 100 iterations an explicit quotient residual is
recomputed. It replaces and restarts a recurrence only when it has converged
or measured drift is material at the registered tolerance. JLA directions are
staged in batches of at most `batch()` columns.

Before either controlled backend runs, rows are put in one control-coordinate-
and ID-free semantic order based on outcome and per-copy target mass. A tie
across nonexchangeable controls, model coordinates, or match blocks is
withheld. A weighted-orthonormal representation of the requested control span
is then reduced to a canonical row-anchor basis. The selected anchor rows
become the identity. The certified range is `k<=32` controls.

The implementation uses the dimensioned envelope stated in
`ESTIMATOR_CONTRACT.md` and derived in
[Control-basis certification](CONTROL_BASIS_CERTIFICATION.md). Weighted Gram,
whitening and reconstruction products use compensated arithmetic with a
second-order row-count error term and absolute underflow contributions.
Only the selected anchor and its predecessors require comparison certification;
the global maximum still includes every row. It covers Gram accumulation, inverse and Cholesky
conditioning, the computed span, every score/cutoff decision, every later
anchor projector, and final anchor/span reconstruction. Maximum-column inverse
residuals are multiplied by `sqrt(k)` and divided by a positive reciprocal-
conditioning remainder. Measured projector and selected-row residuals enter
the envelope directly. The result is then propagated through the full design
and observation/match deletion margins; JLA additionally uses its deterministic
deleted-control rank gap. A propagated value above `1e-8`, a nonpositive
denominator, or an ambiguous pivot returns `AMBIGUOUS_CONTROL_BASIS`.
Adaptive per-column PCG therefore receives the same certified canonical
right-hand sides rather than two raw-coordinate-dependent systems.

After each backend has separately checked the plug-in and correction rows, it
forms their difference and applies another finite-value gate. This last gate
is necessary because subtracting two finite, opposite-signed doubles can
overflow even when both inputs passed their component checks.

Before any randomized calculation with controls is accepted, including
`nuisance(fixedoffset)`, a probe-independent sufficient rank certificate is
applied to the full joint fit and every declared deletion. Controls are
explicitly centered within worker--firm cells in a two-pass calculation and
then whitened by their weighted within-cell scatter. For each deletion
unit, the trace of the whitened scatter it can remove bounds the largest
generalized eigenvalue of that removal. If the maximum trace loss is below
one after subtracting both the measured whitening residual and a rounding
margin, every deleted control scatter remains positive definite at the
registered numerical margin. Each small deleted whitened scatter is also
formed and factored directly; its minimum eigenvalue and inverse residual are
independent acceptance gates. Combined with the FE graph certificate, this rules out
full-sample or deletion-induced loss of design rank without treating
approximate FE-solve error as genuine control variation or trusting an
underestimated JLA leverage. Designs that are valid but fail this conservative
certificate must use the exact backend or revise the control parameterization;
they are not randomly accepted.

## Improved JLA passes

The first randomized pass estimates FE projection and residual shares and
their raw fourth moments. Projection and residual estimates are divided by
their common sum so they remain complementary. The coefficient-one
finite-projection correction is then applied. Exact residualized-control
leverage is added separately under `nuisance(joint)`.

The second randomized pass factors each target centering matrix through
Rademacher directions. Worker, firm, and total contractions use common
directions. Covariance is computed probe by probe as

\[
(\text{total}-\text{worker}-\text{firm})/2,
\]

so both plug-in and corrected accounting identities hold at machine
precision.

The second pass consumes new directions that are disjoint from the first-pass
leverage directions. Conditional on the realized leverage sketch, the fitted
outcome, residual, exact control projection, and adjusted deleted residual are
fixed when the target-probe mean is formed. No additional stochastic
order-one multiplier from the same leverage probes enters that mean.

With a fixed seed, the command constructs probe atoms from the registered
runtime contract and a canonical order within the observed dense worker,
firm, deletion-unit, and target structure. The order also uses outcome,
per-copy target mass, controls, and an optional `probeorder()` tie-breaker.
It is invariant to harmless row sorting, regrouping the same physical copies,
batch partitioning, solver route, processor count, and scheduling. Tied rows
are valid and are not withheld merely because a pathwise labeling is not
unique. Arbitrarily relabeling observed IDs may produce another valid
randomized draw; it must not change the estimand, identification,
deterministic exact result, or numerical acceptance rules. Sequential
direction generation keeps the logical stream invariant to `batch()`.

The regression design remains collapsed. Observation JLA retains two
cross-probe correlation sums per physical copy, forms every copy's nonlinear
finite-projection multiplier, and averages only the final multipliers within a
stored row. Match and target passes aggregate the same literal copy signs
before the solve. This is draw-for-draw equivalent to the canonical explicitly
expanded calculation.

`e(mcse_conditional)` is the developer Monte Carlo standard error of the second-pass
target-probe mean conditional on the realized leverage sketch. It excludes
leverage-sketch uncertainty, solver error, and econometric sampling
uncertainty.

The public `e(mcse)` reports the selected mode, all by default; its availability
and covariance are described in [the return contract](FAILURES_AND_RETURNS.md).
The default `mcse(all)` attachment adds local covariance for randomness
in both existing point-probe stages. It accumulates parity-fold target means,
pulls them through the fixed-R finite-projection formula and replays each
original leverage atom with bounded certified replay (up to four directions in
Rust or eight in Mata, never wider than the admitted leverage batch). Copy-level nonlinear
multipliers and whole deletion-unit/combined-population scores are retained
before covariance products. The signed cross-fold estimate has coefficient one
on the finite-R interaction term; no variance floor is added.

Derivative state and six fold/score coordinates grow linearly in stored rows,
physical copies or compressed units/cells and the leverage count. A production
row-by-probe cache is prohibited. Replay re-evaluations are separate from unique
estimator draws and preserve the original runtime-scoped stream. Mata restores
the saved post-point streams; the outer command restores the complete caller
snapshot on every exit. Numerical V2 carries the original executor and attachment
intent in a 344-byte request and exports a 176-byte combined work receipt. Its
160-byte point-work prefix excludes replay; replay is separately reconciled.
The result/RHS layouts and all older solve/receipt layouts remain frozen.
Legacy compressed/generic point executors have additive V2 numerical selectors
using their unchanged requests. `mcse(off)` skips new derivative/fold/replay
work. The developer conditional mode retains the earlier numerical diagnostic.
Projection/component-inference results receive no MCSE; the main point
attachment uses the same point and attachment executor selected with MCSE off.
See the [default/interface decision](MCSE_DEFAULT_INTERFACE_2026-09-30.md), [the derivation and interface](ALL_PROBE_MCSE.md) and
[implementation evidence and limits](ALL_PROBE_MCSE_STATUS.md).

## Outcome-centering execution

Omitted `centering()` resolves to Mean before capability and inference
checks for exact and JLA. Explicit `centering(none)` preserves the ordinary
executors. Mean calculates the frequency-weighted retained working-outcome
mean and subtracts it in the point-correction factor, requested projection
covariance proxy and realized component-inference outcome terms. Fixedoffset
first subtracts the fitted nuisance index. Target/projection weights do not
redefine this mean.
It adds no fit, target/leverage directions, or inverse-action solves. The
ordinary numerical attachment consumes that factor and holds its mean fixed.

Corrected exact reuses the ordinary fit, inverse and deletion calculations.
One shared coefficient-space correction system supplies all target
contractions; a bounded exceptional-unit Schur system handles small
denominators. The original system residual and copy-contrast guards remain
admission conditions. Production does not expand an observation-square
projection matrix or refit each target.

Corrected JLA retains the existing full and two-half leverage moments and
uses three corresponding correction maps. The signed target increment is
`2 Delta_full - (Delta_half1 + Delta_half2)/2`. No new random directions or
target solves are added. Its MCSE/covariance is the ordinary Mean calculation
with this increment held fixed; there are no increment derivatives or replay.

Mean and Corrected support existing exact, generic, compressed and hybrid
point routes. Mean also supports projection through the same working-outcome
factor in observation, match and eligible-stayer covariance contractions.
Projection coefficients, full residuals, score loadings and naive covariance
remain unchanged. Highrank and q1 component inference also accept Mean on
existing supported tuples, holding the observed mean fixed. Exact Mata uses
the centered outcome in its target-specific smoother, primitive/polarized
influences and q1 leading/remainder calculations. Native residual-moment
fitting uses unchanged residuals. Its match collapse is
`sqrt(F_g)(ubar_g-c)`. Gaussian error probes are never centered by the observed
mean or their own means; the quadratic trace kernel remains the original
one. Preserve the raw q1 recenter and exact remainder-identity gate. The
calculation omits mean-estimation uncertainty without claiming conditional
validity given that mean. Corrected with projection or component inference
is rejected before RNG.
Correction scratch is forecast and admitted before stochastic work.
Extra-system failures are typed errors and cannot trigger post-RNG fallback.
The additive native centering API configures a prepared generation before
solve without altering the established ABI structures; numerical API 2
remains independent. Native Mean projection additionally requires the additive
projection-centering API 1 capability. Mean component inference additionally
requires component-centering API 1: Rust core readiness bit 16 in the existing
capabilities struct/export plus matching C transport. There is no new DLL
export or ABI layout. Missing metadata is zero, and checks precede
preparation/RNG. Existing combined exact-Mata requests support Mean; native
combined component/projection requests remain unsupported for Mean and None.
Explicit None retains its existing native contract. The Mata runtime build
identity has suffix `component-mean1`, preventing stale inference code from
using the prior calculation. See [CENTERING.md](CENTERING.md),
[MEMORY.md](MEMORY.md) and [the native boundary](../../rust/stata_backend/README.md).

## Native q1 remainder certificate

The direct and raw-recentered q1 remainders can differ because both the
original fit and the influence inverse action are numerical solves. Let
`r = z - X beta_c`, `H = X'X`, `q = Q beta_c + X'R z/2`, and `a` be the
computed influence-system solution, with `R` the diagonal remainder-maker
ratio. The signed discrepancy implied by these accepted solves is

```text
d_solve = r' X a - beta_c' (q - H a).
```

The certificate forms this quantity independently of either scalar remainder
from the existing fitted residual, predicted influence action and retained
full-system residual. It checks
`abs(direct - raw_recentered - d_solve)` against the unchanged threshold
`max(8 * influence_full_residual, 256 * machine_epsilon) * identity_scale`,
where the scale is the maximum of one and the absolute point and two
remainder estimates. Both solves must still pass their original-system and
phase-specific gates. Unexplained discrepancies remain hard failures.

The prior scalar check omitted the original fit's normal-equation residual.
This repair applies to None and Mean, using the appropriate `beta_c`; it is
unrelated to omitted mean-estimation uncertainty. Reported
`remainder_identity_error` remains `abs(direct - raw_recentered)`, without
subtracting the certificate or replacing it by zero. Estimates, influences,
covariances, intervals and solver tolerances are unchanged. The implementation
adds four scalar stack entries, no solves, random draws, row-sized allocation,
ABI layouts or exports.

## Memory and runtime boundary

The JLA path does not form an observation-by-parameter design, a parameter
inverse, or an observation-by-observation projection. API 18 represents each
match residual projection with at most one common direction plus the control
directions, solves the reduced Woodbury system, and checks the resulting
observation-space actions. Its leading storage is linear in stored rows,
physical copies, workers, firms, deletion units, controls, and the chosen
batch size, plus a small matrix quadratic in the number of control directions.
Physical-copy storage is used by observation leverage probes, match
leverage probes, and target probes under literal-frequency semantics.
`physical_limit()` supplies a typed pre-allocation boundary for every selected
JLA route before any of that state is allocated. The package installs the
exact Schur-diagonal and source-informed CMG preconditioners behind one lockstep
solver contract. Routing is structural and finishes before estimator RNG.
Explicit diagonal uses B1. Explicit CMG builds the hierarchy and fails closed
if setup or execution fails. Automatic mode uses diagonal for structurally
small inputs or when CMG setup is unavailable; otherwise it uses the
successfully constructed hierarchy. It records the requested route, selected
route, reason, and any typed pre-RNG fallback cause. It does not run trial
right-hand sides or reject a route using projected work or wall time. Every
production solve still has to converge and pass the complete original-system
residual gate.

`memory_gib()` is an optional direct-allocation budget. Omission supplies no
budget, no detected-RAM substitute and no memory-dependent batch, concurrency
or route choice. An explicit budget defaults to `memorycheck(warn)`;
`memorycheck(error)` enforces forecast admission and `memorycheck(off)`
suppresses memory warnings and rejection. An explicit budget still guides
automatic batches under `off`. A policy alone never supplies a budget.

Rust measures preparation heap payload while processing the actual input,
accounts for overlapping C input/export buffers, and reconciles retained
capacities. Constructed CMG hierarchies supply realized storage and workspace
sizes before estimator random draws. Final phase forecasts account for
selected batches and allocation lifetimes; expected solve storage is
separate from conditional refinement reserve. Admission and warning checks
use the latter-inclusive forecast. A strict check may stop after preparation
has already allocated memory. These are direct-allocation forecasts, not
process RSS or a guarantee against actual allocation failure. Mata retains a
working-data model; its public forecasts exclude historical fixed runtime-RSS
allowances. See [MEMORY.md](MEMORY.md) for timing and returned fields.

`batch(auto)` resolves from the retained structure, applicable constructed
solver and probe/processor limits before estimator randomness. With a budget,
route-specific scratch allowances may reduce the selected width. With an
advisory budget that fits no candidate, planning uses the minimum supported
width and continues. Omission bypasses memory-dependent selection. Explicit
positive integer batches, including 128, are preserved; a strict budget can
reject them. Percentage headroom and wall forecasts remain advisory and are
distinct from conditional refinement storage. Real scheduler memory, wall and
temporary-disk limits remain external hard boundaries. Memory policy cannot
relax tolerances, probes, sample selection, numerical gates or the estimator.

The reusable CMG workspace remains an equality-tested API but is not the
production application path. At 32,768 hybrid vertices it was 34 percent
slower for four-column applications and 74 percent slower for sixteen-column
applications; earlier 100,000-vertex tests were about 63 percent slower. The
production adapter therefore uses ordinary batched CMG applications and
reuses the immutable hierarchy and terminal factors without reserving the
slower workspace matrices.
