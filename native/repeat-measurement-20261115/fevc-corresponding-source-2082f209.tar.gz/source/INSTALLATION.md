# Installing fevc

`fevc` requires Stata 15 or newer (through Stata 19). The package includes precompiled native plugins
for macOS (Apple silicon and Intel), Linux x86-64, and Windows x86-64. No
compiler, Rust installation, or separate plugin download is needed. The macOS
and Linux plugins have been tested inside Stata (the Intel macOS plugin under
Rosetta emulation on Apple silicon). The Windows plugin also passes native
Stata qualification on the private Windows x86-64 test host.
See the [native plugin records](native/README.md) for details.

## Installation

Install `fevc` from SSC in Stata:

```stata
ssc install fevc
```

To update an existing installation:

```stata
ssc install fevc, replace
```

Alternatively, use the community-contributed
[`github` installer by E. F. Haghish](https://github.com/haghish/github).
Install the `github` command once if needed:

```stata
net install github, from("https://haghish.github.io/github/")
```

Then install `fevc` directly from this repository:

```stata
github install johannes-schmieder/fevc
```

Both methods install the programs, help, and native plugins for macOS
(Apple silicon and Intel), Linux x86-64, and Windows x86-64. `fevc` loads
the plugin that matches your computer. SSC provides the version distributed
through SSC; `github install` installs the current `main` branch, which may
include newer changes.

After installation:

```stata
help fevc
fevc_run exact_controls using fevc.sthlp
```

The example uses simulated data and restores your data afterward. Restart
Stata after updating a loaded native plugin. See
[inference support and limitations](fevc/docs/INFERENCE.md).

## Checking the native plugin

After installing or updating the package and restarting Stata, you can
check which features the loaded plugin supports. With the plugins included
in version 0.5.2, all of the following assertions should hold, and the
example should run on the Rust backend. This has been verified on macOS,
Linux, and Windows.

```stata
fevc_rust probe
assert r(progress_api) == 2
assert r(centering_api) == 1
assert r(projection_centering_api) == 1
assert r(component_centering_api) == 1
assert r(component_mixed_api) == 1
fevc_run exact_controls using fevc.sthlp
assert "`e(backend_selected)'" == "rust"
```

The probe values correspond to live progress reporting, outcome centering,
mean-centered projections, and two capabilities that the standard errors
of the components need on the native backend (mean centering, and units
that pool movers and stayers). The 0.5.2 plugins predate the standard
errors of version 0.6.0, which also need `r(component_residual_api) == 1`
and `r(component_repeat_api) == 1`; with them the default reports point
estimates and says why, or uses Mata when you select `backend(mata)`.

## Installing a specific release

To install the tagged
[0.5.2 release](https://github.com/johannes-schmieder/fevc/releases/tag/v0.5.2)
from GitHub:

```stata
net install fevc, replace ///
    from("https://raw.githubusercontent.com/johannes-schmieder/fevc/v0.5.2/")
```

Restart Stata after updating to load the new programs and native plugin.

## Release ZIP and offline installation

Download `fevc-0.5.2.zip` from the
[release page](https://github.com/johannes-schmieder/fevc/releases/tag/v0.5.2).
The ZIP contains only the installation files, programs, help, license
notices, and five native plugins; it does not include tests, development
tools, or benchmark data. Extract it and run:

```stata
net install fevc, replace from("/path/to/extracted/fevc")
```

`SHA256SUMS` and `release-manifest.json` identify the exact downloads and
installed files. The release also attaches the source code used to build the
native plugins; you do not need it to use the package.

## Installing from a source checkout

For development, the package can be installed from a local checkout:

```stata
net install fevc, replace from("/absolute/path/to/fevc/fevc")
```

This installs the Stata and Mata programs and the plugin loaders, but no
plugin binaries, so `backend(mata)` is used unless you build a matching
native plugin. Features that only the Rust backend provides require such a
build; see the [native build guide](rust/stata_backend/README.md).

Restart Stata after replacing a loaded native plugin. After a source update,
restart Stata or run `discard` to clear cached programs and Mata definitions.

## Using a self-built or older native plugin

The Mata backend (`backend(mata)`) runs on every platform and supports most
features. In Mata, projections use exact calculation and are therefore
limited to small designs; the standard errors of the components run with
`algorithm(jla)` as a separate stage of about the cost of the point
estimates, or with `algorithm(exact)`. Live progress and `rng(counter_v1)`
require the Rust plugin; see the
[backend reference](fevc/docs/RUST_MATA_PARITY.md). A self-built or older
native plugin may lack some features. Check it with
`fevc_rust probe` and `return list`:

- `r(centering_api) == 1` is needed for outcome centering with the Rust
  backend;
- `r(projection_centering_api) == 1` for mean-centered projections;
- `r(component_residual_api) == 1`, `r(component_repeat_api) == 1` and
  `r(component_mixed_api) == 1` for the standard errors of the components,
  and `r(component_centering_api) == 1` for them under mean centering; and
- `r(numerical_api) == 2` for the numerical MCSE.

A value of 0 means the feature is not available. When a feature is
missing, `backend(auto)` uses Mata if it can do so before estimation starts.
An explicit `backend(rust)` or `rng(counter_v1)` stops with an error instead.
For the numerical MCSE, an omitted `mcse()` keeps the native point estimates
and reports the MCSE as unavailable, while an explicit `mcse(all)` stops with
an error. For the standard errors of the components, the default reports
point estimates with the reason, while `inference(highrank)` or
`inference(q1)` stops with an error. With `project()` the default reports
point estimates for the components, and an explicit `inference(highrank)`
or `inference(q1)` stops before estimation. See the
[centering guide](fevc/docs/CENTERING.md) and the
[native plugin records](native/README.md).

## Upgrading an older development installation

Some earlier development versions used helper files named `_fevc*.ado`;
these are now named `fevc__*.ado`. The public `fevc` command and plugin
filenames are unchanged, and the old helper names are not installed.

Before installing this version over an earlier development installation:

1. Run `ado uninstall fevc` while the old installation is still registered.
2. Install the current package using one of the commands above.
3. Restart Stata to clear cached programs and loaded native plugins.

Using `net install ..., replace` alone leaves the old helper files behind.
If files were copied manually or several installations exist, inspect
`which fevc` and `adopath` and remove only the identified old package files;
the installer does not delete files by wildcard, and other packages can also
have underscore-prefixed filenames.
