# 0.6.0 Windows dispatch repair and new common build — November 15, 2026

The owner authorized investigation and fixes after the first Windows campaign
failed its observation-component regression. Explicit generic JLA with a diagonal
preconditioner on Windows reached the old point-only helper and dropped requested
repeat-measurement inference. The narrow dispatcher fix admits only an already
supported generic tuple to the inference-capable helper, retaining the Windows
legacy diagonal executor, backend and solver. Point-only requests are unchanged.
The strict regression and added automatic-inference check pass in a bounded
Windows development run; this is not qualification. The failed confirmation and
all diagnostic attempts remain preserved.

The production change supersedes build `e9c5f969`: rebuild and qualify all five
binaries from one new common commit. That earlier build passed macOS, Linux and
Stata 15.1 full/installed/default checks. The accepted private Windows runner
supports the new 149-export/checks-V5 boundary. Its unchanged 0.6.0 qualification
protocol and harness are preserved at `60e75328` as an exact overlay, to be adopted
with the new binaries and manifest. Until adoption the checkout retains the
0.5.2 payload's matching release-harness files, so source tests validate the
actually distributed artifacts. No threshold, seed, group or failure is changed.

Next: pass source gates, freeze the common build, rebuild/requalify macOS, SCC
Linux and Stata 15, then run a newly registered 18-group Windows campaign against
0.5.2. Make one adoption commit including the qualified binaries, preserved
qualification harness, manifest, documentation and repointed tests; check/build
release assets, push/tag/publish, verify HTTP installs and close PR #8. Stop on
required authentication or a new formal qualification failure. Publication and
code fixes are already authorized.

## Previous checkpoint

# 0.6.0 Stata 15 compatibility and release — November 15, 2026

The owner authorized the complete release, private Windows runner/protocol
updates and publication, then lowering the minimum to Stata 15 and fixing
compatibility defects without renewed approval. Work is on local `main`,
fast-forwarded to `80e163c2`. The compatibility edits supersede the original
`d4b2d942` build: freeze a new common source after source gates, then rebuild
and qualify all five binaries before adoption. Old receipts remain immutable.

Current development checks: repeat-measurement intervals, actual default native
commands, lifecycle and RNG restoration pass on Stata 15 and 19. Stata 18
passes focused compatibility/load/RNG/default checks; the installed Stata 17
license is expired, so no Stata 17 execution is claimed. Symmetric target
normalization and a canonical direction within repeated eigenspaces repair
the old runtime's eigensolve and literal-expansion equivalence. Native RHS
diagnostics use Mata transport to preserve complete ledgers beyond Stata 15's
11,000-row matrix-write boundary. Independent row checks and the original
4,096/8,192-probe pooled oracles pass. The full Stata 15 development attempt
passed all 256 pooled Monte Carlo fits, then stopped on a fixture version
declaration. After its repair, every remaining full-suite test passes. Clean
portable installation, both helper migrations, CMG and benchmark harness checks
pass; 1,019 Python tests pass. A single full Stata 15 run with the newly built
Intel plugin remains required.
All development failures and incomplete attempts are retained privately.

SCC access is restored. The original Linux qualification job `8622690`
passed scheduler accounting, the full suite and clean install; its collected
artifacts remain bound to `d4b2d942`. A new frozen-source run remains required.
Windows preparation is local: the proposed 0.5.2 comparison keeps 18 groups,
144 paired point-only commands, seeds and all scientific/timing thresholds;
default-SE timings are separate information. The export/collector changes and
runner reacceptance remain pending after Linux. Offline maintenance tests pass;
the owner-maintenance browser session returned AUTH_REQUIRED and needs renewal.
No new binary is adopted,
no tag is created and no release is published.

Next: freeze the checked common source, qualify Linux/macOS and
Windows under the authorized order, make one adoption commit, build/check
release assets, push/tag/publish, verify HTTP installs, record evidence and
close PR #8. Stop for required authentication; preserve failed qualification
and keep registered gates unchanged.

## Previous checkpoint

# 0.6.0 release candidate: standard errors by default — November 14, 2026

Branch `repeat-measurement-se` (draft pull request #8), not released. The
plain command reports standard errors for the four components, from one
method (owner's decisions of 2026-11-13 and 2026-11-14): the
repeat-measurement model, with one interval per component, normal or
`q = 1`, chosen from the leading direction's share of the estimated
sampling variance (above ten per cent, the owner's threshold); `e(V)` when
every component is normal; with controls, the estimation of their
coefficients to first order. `inference(highrank)` and `inference(q1)` are
the strict requests; `inference(none)` gives point estimates. The variance
models of 0.5.2 and the never-released leave-out residual model are
removed from the command. See the [decisions](docs/DECISIONS.md) and
[INFERENCE.md](docs/INFERENCE.md).

Evidence: dense-oracle and cross-route regression
(`tests/stata/test_repeat_measurement_se.do`); simulations through the
command with the harness in `tools/default_interval/` (records in
`docs/default_interval/`). Without controls: development (32,000 fits), a
first confirmation that FAILED on the bookkeeping of one fit that returned
point estimates, a second that passed (40,000 fits; lowest coverage 0.930,
mean 0.959). With controls: development (26,000 fits, none failed) and a
registered confirmation on 20 new designs that passed (40,000 fits; lowest
coverage 0.923, mean 0.960), run on the source `f3938986` and its
qualified macOS arm64 plugin; the release source gives bitwise the same
results for 36 default requests on every route. End-to-end on three Veneto
panels with the default of `fb49e16d` (no controls): all components
normal, 24% to 30% more time than the point estimates. Named limits: the
joint estimate's additional term in the control index; error variances
that move with a control inside a cell; two or more dominant directions;
outcomes with almost no noise.

Native binaries at the build commit `d4b2d942`: macOS qualified
(`CLEAN_LOCAL_MACOS_CANDIDATE_QUALIFICATION`: arm64 `6dc228a0...81c5`,
x86_64 under Rosetta `8df483a3...7158`, universal `766aa624...6331`);
Linux built and checked on SCC by a diagnostic job (plain default,
standard-error regression, quick suite; scheduler `failed=0`), not yet the
registered qualifier; Windows built and audited by the hosted workflow
(plugin `addb9a4c...caa8d`, static CRT, PE audit, 149 exports), not yet run
under licensed Stata. Hosted source checks, Rust backend and
plugin-interface candidates pass at the build commit. Candidates and
receipts are kept outside the repository until adoption.

Open, for the owner, in this order:

1. Fast-forward `main` to the build commit (the branch is a fast-forward of
   `main`; a merge commit would give the Linux build another source commit
   than the other binaries), then run the registered Linux qualification
   (`rust/stata_backend/scc/deploy_linux_bundle.sh`, which requires `main`).
2. Windows: approve the change of the private runner's export list (three
   additive diagnostics exports) and a campaign protocol against 0.5.2
   (the 0.5.2 protocol compares with 0.5.1, times plain calls, which now
   compute standard errors, and its cell 5 uses a removed model); then the
   18 licensed runs.
3. The adoption commit: the five binaries, the adoption manifest, the
   release links in `README.md` and `INSTALLATION.md`, a parity-matrix row
   for the repeat-measurement standard errors, and the status documents of
   the distributed binaries; then `fevc/tools/build_github_release.py`, the
   tag `v0.6.0`, the release and the install checks.

Not claimed: a theoretical result for the data-dependent choice between
the two intervals; simulations on the Mata routes beyond the regression
tests.

## Previous checkpoint

# Windows full-CMG 0.5.2 released — November 7, 2026

[fevc 0.5.2](https://github.com/johannes-schmieder/fevc/releases/tag/v0.5.2)
is published at package commit `3744dd68e808c8a7b7b5cede9cf364c27da3d22d`.
All five plugins share qualified build source
`ec5e1e0ec4428d7a4410c7ce4d2709df006a8da4` and unmodified common CMG
`e5613e81fb3b03c78de98658b372646fa802aabb`, explicitly configured to 128 levels.
The Windows full-CMG platform restriction is removed for supported routes.

The [final audit](../native/windows-cmg-20261107/final-audit.json) binds all
binary and source hashes, exact release assets, platform evidence and cleanup.
All 18 Windows groups, 144 retained timed commands and 12 scientific/timing
cells pass the frozen rules without exclusions or resampling. Mac arm64/Rosetta,
SCC Linux smoke/full/native/installed, hosted builds and Rust/MSRV checks pass.
The final package passes 952 Python tests, source/vendor/license/assembly checks,
and published-commit Source checks and Rust backend CI.

All eight actual tag/main/GitHub/downloaded-ZIP fresh/replacement installs pass
on Mac arm64, verifying all 61 installed files and five plugin hashes per case,
native and pooled inference, and caller-state/timer restoration. Published
assets equal the verified local assets byte for byte. Separate Windows and
Linux runtime receipts retain their exact E identities. The temporary hosted
branch is deleted after verification, owned temporary transports are removed,
and the Windows machine is stopped. Unrelated CMG work remains untouched.

Earlier failed registrations, C timing failures, adverse D/E pilot observations,
superseded incomplete qualifiers and the repaired package-test failure remain
preserved. Windows runtime scope is one/two workers and the declared fixtures.
Mac x86-64 tests use Rosetta; native Intel hardware, representative-scale
performance and general statistical coverage are not claimed.

## Previous checkpoint

# Windows full-CMG scheduling fix — November 7, 2026

The result-export fix at `05f806ce` passes the Windows development scientific
checks, but paired pilot timings still show small-case regressions. No new
confirmation was started. Its completed hosted builds, Windows smoke/pilot and
Linux smoke are retained; the remaining Mac/Linux qualifiers were intentionally
stopped as incomplete when this candidate was superseded. Released plugins
remain unchanged.

The next candidate keeps the validated result export and adds two narrow fixes:
execute single-lane/single-item independent work locally, and wake the caller
when its coordinated solve completes. Callback ownership, cancellation polling,
worker joining, memory admission, solver behavior and scientific/performance
criteria stay unchanged. Focused Rust and Stata diagnostics, the full Rust workspace, Clippy,
952 Python tests, assembly, vendor and parity checks pass. Freeze the new
candidate, rebuild matching artifacts and pass a new
Windows development pilot before registering confirmation. See the
[scheduling review](../native/windows-cmg-20261107/scheduling-fix.json).
Publication remains blocked until all required qualification passes.

## Previous checkpoint

# Windows full-CMG qualification — November 7, 2026

The Windows implementation and all six runtime/installation groups pass at
build source `7cc07a5658532e8dd5cc8716fcaa81aeabc3ec20`, using unchanged CMG
`e5613e81fb3b03c78de98658b372646fa802aabb` and explicit 128 levels.
All 18 confirmation runs completed with verified cleanup. All 12 scientific
cells pass, but six timing cells fail the fixed max(5%, 1 ms) allowance:
controlled weighted observation, projection and pooled inference at one/two
workers are 26–46% slower. Larger generic paths improve substantially.
All 144 timed commands and the original failed registration/development pilot
are retained. See the [complete result](../native/windows-cmg-20261107/confirmation-result.json)
and [raw comparisons](../native/windows-cmg-20261107/evidence/confirmation-attempt1/comparison.json).

Publication and binary adoption remain blocked. A narrow Stata result-export
fix is ready for source checks and new platform qualification. It holds and
restores the already validated immutable result across auxiliary receipt getters,
avoiding duplicate exports. The red/green regression and affected one/two-worker
cancellation, memory and numerical tests pass. See the
[fix review](../native/windows-cmg-20261107/result-export-fix.json).
Preserve the failed confirmation; do not resample the unchanged candidate, relax thresholds or silently
change solver routes. A justified implementation fix requires a new source,
matching platform artifacts and a newly registered affected confirmation.
The installation payload still contains the released 0.5.1 plugins. Mac/Rosetta,
SCC Linux, hosted Windows/Rust/SPI, 952 Python tests and exact candidate local
fresh/replacement installation all pass within their recorded scopes. The
approved temporary hosted branch remains until release. Shared Windows repair
cycle 1 is accepted; the last run cleaned up and stopped the machine.

## Previous checkpoint

# CMG consolidation — November 6, 2026

The owner authorizes one common CMG main revision, new 0.5.1 plugins and
release packages after qualification, and removal of abandoned CMG branches.
The common revision is `e5613e81fb3b03c78de98658b372646fa802aabb`,
now frozen on CMG main. The vendor payload is byte-identical to upstream.
FEVC owns its pool and input-ordered dynamically claimed RHS queue and uses
public contexts, explicit 128-level configuration, and checked caller-buffer PCG.
Root, plugin and fuzz lockfiles use CMG 0.2.0.

Exact replacement build `94d94999be54e9a2309497d5fbe9899e2822cd51` passes
full Mac arm64/Rosetta native and installation qualification, hosted Rust/MSRV
checks, and private Windows smoke/full qualification. The shared full-CMG
public route remains Mac/Unix only; Windows boundary coverage verifies its
existing compressed/exact route, residuals and caller-state restoration.
SCC Linux smoke 8488089 and full native job 8488094 pass; all 66 collected
files match their remote inventory hashes.

The [four frozen comparisons](../native/cmg-consolidation-20261106/evidence/performance/README.md)
retain the earlier timing failures and development-binary pass. The exact new
qualified Mac arm64 binary passes all four cells (+0.6% to +3.3%) and all
scientific gates under the unchanged max(5%, 1 ms) allowance. Every study
retains all 96 observations; no adverse measurements were repeated or excluded.

The five exact source-bound plugins, corresponding source and platform evidence
are assembled in the local package. All 913 Python tests, 28 independent CMG
tests, integrated Stata quick/full checks, and fresh/replacement installations
pass. The 63-file ZIP matches the tested 61-file installed payload exactly.
See the prepublication checks and installation records beside the adoption manifest.
Johannes accepted fereg's two inconclusive Mac timing cells as explicit release
exceptions on November 6. Their measured status and all prior adverse evidence
remain unchanged. CMG 0.2.0 and fevc 0.5.1 are published. All eight actual
published-install cases pass: tag/main/github/downloaded-ZIP fresh/replacement,
all 61 installed file hashes, native component and pooled inference, and caller
state/timer restoration. The release manifest binds package commit `117d09c5`
and actual build source `94d94999`. See the [publication record](../native/cmg-consolidation-20261106/evidence/publication.json).
Only documentation and evidence change after the immutable release tag.
## Previous checkpoint

# GitHub release 0.5.0 — October 14, 2026

The owner authorizes a regular `v0.5.0` GitHub release, including the current
Windows binary, a runtime-only installation ZIP, `github install` and
`net install` support, short release notes, and current documentation updates.
The starting source is `4419a98a`. All five native binaries retain their
October 10 hashes and build source `002205f2`; Windows Stata runtime testing
remains pending and is not relabelled as passed.

The release updates public version strings to `0.5.0`, installation metadata,
current release wording, and packaging tools. No estimator, algorithm, native
build input, scientific input, acceptance threshold, or binary is changed.
The ZIP contains the same 61 installed files as the repository catalog, plus
the two installation catalogs. Corresponding source and checksum/inventory
records accompany it. Tagged repository archives include the plugins needed
by the root catalog. The separate portable-source catalog remains binary-free.
The SCC source-bundle exporter explicitly omits plugins so qualification still
rebuilds from source. Version-only result guards accept the new release status
without treating a version query as fitted results.

Validation uses the integrated local checker, deterministic ZIP and inventory
checks, existing adoption evidence/hash checks, and fresh/replacement Stata
installations from the extracted ZIP and published repository. The final
release manifest binds the exact package commit, archive and installed hashes,
original build source, and unchanged platform limitations. Original receipts
below remain immutable. New platform builds and scientific campaigns are not
needed for these version, documentation, and packaging changes.

## Previous checkpoint

# Installation documentation refresh — October 13, 2026

The owner requests verification that the latest code is online, removal of the
stale October 8 candidate warning, and explicit instructions for
`github install johannes-schmieder/fevc` with a link to Haghish's installer.
GitHub `main` and the clean local checkout both start at `c5f2025b`; the current
code and all five plugins were already published. The warning originated in
`623b156d` and was superseded by subsequent publications.

This documentation update changes only `README.md`, `INSTALLATION.md`,
`fevc/README.md`, `fevc/docs/CENTERING.md`, and this checkpoint. It aligns current
availability and platform descriptions with the October 10 adoption, including
pooled inference and the pending Windows Stata runtime test.
The tested package source remains `819d4c51`, with build source `002205f2` and
the [existing public-install binding](../native/pooled-component-20261010/evidence/packaging/public-install-binding.json).
Production, build, binary, input, harness and acceptance identities are unchanged
from the starting checkout. Historical installation and platform claims retain
their original artifacts and limitations; no new runtime qualification is
inferred from documentation changes.

Validation passes with Python 3.13.0 and Stata/MP 19.0.115:
`./.venv/bin/python fevc/tools/run_checks.py` includes all 894 Python tests,
`./.venv/bin/python fevc/cmg/tools/assemble.py --all --check`, source audits,
CMG checks, Stata quick/full suites, clean installation, helper migration and
benchmark smokes, ending with `FEVC LOCAL QUALIFICATION PASS`. Registered test
seeds and tolerances are unchanged. Relative documentation links and
`git diff --check` pass. All 61 installation files and both catalogs match
`819d4c51` byte for byte; a fresh public HTTP check also matches every file,
including the five plugin hashes in the original public-install binding.
No external platform or native-build gates are rerun for this documentation
change. The owner requests publication of this update on `main`.

## Pooled inference package publication — October 10, 2026

The owner requests current component-inference help, all updated native binaries,
a verified installation package, and commit/push to main. Source and help are
published at `002205f2`. The help describes exact Mata for small designs and
scalable Rust/JLA, independent physical stayers, supported variance models,
fixed nuisance offsets, covariance availability, and hard numerical failures.

All five binaries are rebuilt from that exact source and adopted under the
[manifest](../native/pooled-component-20261010/manifest.json). Clean Mac
arm64/Rosetta thin/universal qualification and SCC Linux job 8015131 pass,
including pooled inference and clean-install checks. All 894 Python tests,
CMG assembly, license audit, and hosted source/Rust/Windows build checks pass.

The owner now explicitly says: “Leave windows authentication as is. Push the
binaries anyways. I'll run windows later.” Windows hosted build/unit/PE/export
checks pass; private Stata runtime was not run and owner manual testing remains
pending. Authentication and the stopped private machine are left unchanged.
The complete 61-file repository installation package is published at `819d4c51`
with all five plugins. Local HTTP fresh/replacement and all four public
net/github fresh/replacement cases pass on Mac arm64: every installed file hash,
pooled components with both models/backends, match q0/q1 and caller-state checks.
The [public binding](../native/pooled-component-20261010/evidence/packaging/public-install-binding.json)
records the exact package commit and unchanged production/build/test identities
from `002205f2`. The follow-up commit adds documentation/evidence and updates the
ledger regression to require the explicitly deferred Windows status; estimator,
build inputs, installation payloads and runtime qualification gates are unchanged.
No tag or native release archive is created.

The historical checkpoints below retain their original source, authorization,
failures and evidence scope. They do not qualify the newly adopted binaries.

## Historical diagonal residual refinement checkpoint

The owner approved bounded refinement for the generic Rust diagonal solver.
A failed complete-equation check now receives at most three corrections using
the same prepared operator and preconditioner. The acceptance threshold,
passing-column arithmetic, original RHS, estimator, and RNG counts remain
unchanged. Work receipts and the memory forecast account for correction work;
exhaustion remains a hard error. Independent physical-row tests cover recovery,
cancellation/reuse, and failure when the original equations are incompatible.

Both original 240,000-row highrank/q1 examples now complete locally with the
same data, seeds, solver route and numerical budgets. Their maximum reported
full residual is `7.5535e-10`, below the unchanged `1e-9` threshold. Highrank
returns three intervals and q1 returns four. Logs and source/binary identities
are in `.local/diagonal-refinement/`. These are development reproductions;
concurrent test activity makes their times unsuitable for a controlled speed
comparison. The old failures remain unchanged.

The full Rust workspace, 894 Python tests, formatting, strict clippy and CMG
assembly pass. Mac arm64/Rosetta thin/universal runtime, ABI and installation
checks pass with source manifest `0860cd30f727646d79db31f02071b47afbaaf97381fc0ebdc5feb642de497605`.
The formal `plugin-build` CI receipt remains `failure/dirty_checkout`: the
underlying qualifier exited zero as `LOCAL_CHECKPOINT_DIRTY_TREE`, but the CI
wrapper requires a clean committed checkout. This is preserved, not waived.
Integrated Stata quick/full, clean installation, helper migration and benchmark
smokes pass with the rebuilt candidates (`FEVC LOCAL QUALIFICATION PASS`).
All five distributed plugins were restored and verified byte-for-byte against
HEAD after testing. This production solver change means
the preceding Mac/Linux candidate qualifications below do not qualify the new
binary revision. No new Linux or Windows qualification is claimed. The Windows
collector approval remains valid, but authentication still requires manual Mac
unlock/login. Distributed binaries retain their original bytes. No commit, push, publication, tag or release is authorized.

## Pre-refinement pooled-inference checkpoint

# Pooled mover–stayer component inference — October 9–10, 2026

The owner approved implementation of [the pooled inference plan](docs/POOLED_COMPONENT_INFERENCE_PLAN.md).
The source implementation is complete in scalable Rust/JLA and exact Mata,
with explicit structured variance models, fixed nuisance offsets, original
unit classification and independent physical stayer observations. The work
remains uncommitted on main. No publication, push, tag or release is authorized.

The [bounded assessment](docs/POOLED_COMPONENT_ASSESSMENT.md) completed 16,000
calls: all primary intervals were available and all registered descriptive
screens passed. Every diagnostic failure and the stopped pre-repair attempt
remain preserved. These results do not establish general coverage; null,
weak-signal and multiple-mode cases remain problematic, and numerical probe
sensitivity is material in some fixed outcomes.

Independent dense/physical-row and literal-expansion oracles, source checks,
integrated Stata quick/full, Rust core/plugin targets, ABI and public regression
checks pass. Three source-bound Mac candidates pass arm64 and Rosetta
thin/universal qualification. Local HTTP fresh/replacement installation checks pass, verifying all 61
installed bytes and both models on both backends. The final Python gate passes
894 tests; assembly, formatting and clippy pass. The three-size timing
assessment is complete with explicit limitations: 240,000-row diagonal calls
failed the unchanged residual gate; CMG diagnostics completed in 57.0 seconds
(highrank, three targets) and 42.0 seconds (q1, four targets), at 605/582 MiB
process RSS on an M2 Ultra with two native threads. Original failures remain
in [the performance record](docs/pooled_component_inference_performance_v1.json).

The owner explicitly approved the frozen SCC bundle and the prepared private
Windows collector update. SCC job `8010602` passed the four staged pooled
checks and full Stata suite, then failed clean installation with `r(601)`
locating a fixture in its temporary test copy. Its failed accounting and
37 hash-verified evidence files are preserved. The frozen fixture exists;
the lookup failure's mechanism is not established after temporary cleanup.
One focused four-core retest, job `8011621`, passed clean installation and all
12 installed checks using the immutable fixture directory and identical binary.
Its accounting has zero failed/exit status; all 32 collected evidence files
match remote hashes. The retest took 354 seconds with 930 MiB peak virtual
memory. The permanent qualifier now uses the immutable source fixtures, and a
focused regression covers an incomplete temporary copy. Both attempts retain bundle
`fb1b52c85bd40e50cb786d9e61bc5e2cd5bf77661f9275464e4c726936d1febf`
under `/projectnb/welfgr/vckss/runs/20261010T042343Z-pooled-component-final`.
Linux candidate qualification is complete through the combined full/staged
and installed evidence; the original failed attempt remains failed. The local
`linux-install-retest/composite-qualification.json` records that reuse and its
unchanged source, binary, fixture and acceptance identities.
Windows maintenance stopped at `AUTH_REQUIRED` before acquiring a lock or
changing the controller. The owner-authorized browser login attempt could not
fill the saved credential; the computer-use tool then reported the Mac locked
and requiring manual unlock. Authentication must be completed interactively.
The restricted inspector confirms that the Windows instance is stopped.
Earlier approval-review rejections remain recorded in the local approval brief;
the new owner approval resolves the authorization issue.
The three qualified Mac candidates and the Linux candidate are preserved under
`.local/pooled-component/`;
the qualifier's copies into tracked binary paths were restored to their original
bytes. All five distributed binaries remain unchanged and lack the new mixed
capability. Five-payload adoption is not complete.

## Preserved completed checkpoint

# CMG replay, refinement and sample reporting — October 9, 2026

Commit A `a8617882` and Commit B `eec825d6` were reviewed, committed and pushed
on `main` after the owner's explicit source-push/hosted-dispatch approval.
All five payloads are rebuilt from B, qualified and published at `13a98492`
after explicit owner approval. Public installation checks pass. The final
receipt update changes documentation/evidence only; all 61 installed files
retain their tested bytes. No tag or release is authorized.

[The adoption manifest](../native/cmg-defects-20261009/manifest.json) binds the
five actual B build sources, hashes, corresponding source and installation
receipts. [The checkpoint](../native/cmg-defects-20261009/checkpoint.json)
preserves every failed attempt; preceding accepted records remain unchanged.

- A aligns CMG_FULL_V2 replay validation with the posted phase gate and
  distinguishes original histories, singleton/unattached exclusions and
  included hybrid stayers in `estat sample`. Both Stata regressions are
  registered. [Compatibility](../native/cmg-defects-20261009/evidence/source/compatibility-A.json)
  records unchanged native/build/input/acceptance identities and all five
  preceding adopted payload hashes; their original qualification limits remain.
- B targets warm-start refinement to `factor*gate*min||b||` with relative
  tolerance zero for a valid positive target. Complete-system certification
  remains mandatory. The stopping-option, weighted-grid/hub and existing
  refinement-schedule tests pass. No estimator, sample or acceptance cutoff changes.
- Frozen-source pytest passes 890 tests; assembly, license audit and integrated
  quick/full Stata checks pass. The earlier staged-tree quick receipt remains
  bound to `7d75328f`, rather than being relabelled as clean B evidence.
- The registered Mac qualifier passes thin arm64, x86-64 under Rosetta and
  universal builds. Four installed defect cases pass. Public Veneto default
  and automatic-batch projection calls pass on installed arm64 bytes.
- SCC Linux job `7981653` passes full and installed qualification at B;
  scheduler failed/exit status are zero and all 46 collected hashes verify.
  The exact bundle hash and 1,529 source identities remain in its receipt.
- Hosted Windows build `37938556177`, Rust matrix `37938525123` (all jobs),
  and source checks `37938525129` pass at B. Exact-artifact private smoke
  `win-20261009T135537Z-6d364439` and full
  `win-20261009T140221Z-834b89b4` pass. Input/source restoration, transient
  cleanup, lock release and stopped state are verified. Only the unchanged
  pinned shared backend acceptance is reused; native qualification is new.
- Complete-profile package validation and local HTTP fresh/replacement checks
  pass. Each case verifies 61 installed files and five plugin hashes, existing
  installed regressions, both new tests, eight Mean-component cells and the
  public Veneto projection with automatic batch. Execution is on Mac arm64;
  all platform runtime claims retain their separate qualification receipts.
- The common B corresponding-source archive verifies all 1,528 exported Git
  blobs and modes, including source, locks, build scripts, generated CMG and
  notices. SHA-256 `e119dbcb138fca624df7c75355184ca9c8298cd6c3e76a256a9886add5cfec09`.
  Public row-level fixtures remain outside the repository and are hash-pinned.
- Preserve missing-rustc PATH, concurrent-snapshot pytest (889 pass/one failure),
  sandbox SSH/credential failures, rejected initial push/dispatch and SCC
  collection-mode warnings. Frozen reruns and explicit approval resolved their
  respective blockers without relabelling the failures. Optional local process
  inspection was unavailable; terminal install receipts remain authoritative.

Native Intel hardware, representative-scale performance and general coverage
are not claimed. Mac qualifier supervisor timing is unavailable and recorded
truthfully. Historical scientific failures below are unchanged.

## Completed publication checkpoint

The owner approved publication of the reviewed `13a98492` payload/checkpoint,
public installation checks and the receipt push. Source checks pass at the
published package source. Actual HTTP preflight verifies 65 files, including
all five binaries, the adoption manifest and the B source archive.

All four public `net`/`github` fresh/replacement cases pass on Mac arm64. Each
verifies 61 installed files and five binary hashes, both new regressions,
existing runtime/caller-state checks, eight Mean-component cells and the public
Veneto automatic-batch projection. [The receipt](../native/cmg-defects-20261009/evidence/packaging/public-install-13a98492.json)
and [exact binding](../native/cmg-defects-20261009/evidence/packaging/public-install-binding-13a98492.json)
retain the actual published source and execution scope.

[Compatibility](../native/cmg-defects-20261009/evidence/source/package-compatibility-13a98492.json)
compares B with `13a98492`: all 1,521 other tracked blobs/modes are unchanged,
including production/build/test/input/acceptance sources. All 63 staged
repository files match the published checkout. Actual qualified B binaries
retain their original hashes; the previous binaries checked into B are not
relabelled as repaired builds. Frozen campaign receipts, manifest and earlier
failed attempts remain unchanged. The final broad source check first returned
889 passed / one failure because the dirty-source bundle guard rejected the new
untracked public receipt; its original log is preserved. After staging the
reviewed evidence, all 890 tests pass. The 77 focused packaging/documentation
checks, CMG assembly check and parity renderer check also pass. A scoped
whitespace attribute preserves the failed log byte for byte. The append-only
[publication checkpoint](../native/cmg-defects-20261009/public-checkpoint.json)
records these final checks and diagnostic attempts. No tag or release.

## Preserved preceding checkpoint

# Mean-centered component inference — October 8, 2026

The owner accepted all five recommendations in
[the implementation plan](docs/MEAN_COMPONENT_INFERENCE_PLAN.md): highrank and
q1 on existing supported routes, the Mean default with a fixed-observed-mean
approximation, independent tests and a bounded sampling assessment, all-platform
native qualification/adoption, and reviewed package/paper commits and pushes.
Work stays on `main`; tags and hosted releases remain separate decisions.

## Current checkpoint

- Source `63757839` implements Mean component inference and discloses omitted
  mean-estimation uncertainty. Gaussian error probes remain uncentered.
  Corrected inference and existing unsupported tuples remain withheld.
  Native `component_centering_api=1` uses readiness bit 16 through the existing
  capability interface, with no ABI layout or export-inventory change.
- Independent exact/native fixed-c oracles, q1 imperfect-solve and fault tests,
  caller-state/capability regressions and pinned clean Rust source gates pass.
  The integrated checker passed on the earlier staged development tree; its
  receipt is not relabelled as a clean-source integrated run. The final 32
  harness tests pass at `b9f80ce9`, with identical harness bytes at `63757839`.
- The shared None/Mean q1 certificate repair accounts for both accepted solves'
  signed normal-equation residuals at unchanged tolerances. Public raw
  remainder discrepancies, estimator values and solver gates remain intact.
  The preserved failing draw and independent dense checks pass after repair.
- All five qualified payloads are adopted and published in `66d0278b`. Mac
  thin arm64, thin x86-64 under Rosetta and universal builds retain full qualification at
  `b9f80ce9` and installed Mean checks across all four aliases. Linux retains
  full and staged/installed Mean qualification at `63757839` (SCC job
  `7969972`). Their original bytes and corresponding-source archives are
  retained under an affected-route compatibility review limited to unchanged
  public routes. They do not contain the lower-level serial exact Corrected
  repair in `240ad74d`. The [adoption manifest](../native/mean-component-20261008/manifest.json)
  binds their original identities and the new Windows candidate.
- The [completed assessment](docs/MEAN_COMPONENT_INFERENCE_ASSESSMENT_20261008.md)
  accounts for all 48,000 primary calls and 192,000 target rows. **All 22 failed
  primary screen entries are exact-Mata availability failures**, affecting
  highrank k12/k20 and q1 k12 in both arms. The eight native cells have 100%
  interval availability and pass the broad descriptive screens. Stress and
  fixed-outcome numerical profiles are complete; material numerical
  sensitivity and historical calibration failures remain limitations. There
  is no general coverage claim and no changed cutoff or discarded attempt.
- Reviewed source `240ad74d` is pushed. Its hosted Windows build, Rust and
  source checks pass. The identical Windows artifact passes private smoke and
  full qualification; full run `win-20261009T023703Z-209dc9ed` includes installed
  Mean component and Corrected exact checks. Cleanup/source restoration pass
  and the machine is stopped. The [Windows summary](../native/mean-component-20261008/evidence/windows/qualification-240ad74d.json)
  records four of the 15 authorized infrastructure repair cycles and retains
  all prior failed attempts.
- Local forced-Windows-serial execution reproduces the first Corrected cell's
  `CORRECTION_NONFINITE` failure (native status 71, `exact_stayer_hybrid`). The
  repair at `240ad74d` materializes the scalar total before checked Corrected
  addition, preserving final reconstruction and numerical gates. Focused
  checks pass: 890 Python tests, CMG assembly, 23 existing exact-core tests,
  15 exact FFI tests, a 36-cell serial/parallel accounting regression, strict
  core Clippy and formatting, and the unchanged official 12 Corrected and
  12 Mean-component cells under serial emulation. The new regression fails
  when the three-line repair is removed. Final independent source review
  passes, followed by actual Windows qualification of the rebuilt artifact.
- [Local staging and HTTP fresh/replacement checks](../native/mean-component-20261008/evidence/packaging/local-install-240ad74d.json)
  pass at `240ad74d` on Mac arm64: both cases verify all 61 files and five
  plugin hashes and run eight installed Mean-component cells. These receipts
  retain the help bytes at that source. The adopted package is published at
  `66d0278b`. Its four public `net`/`github` fresh/replacement cases have status
  PASS on Mac arm64 under Stata 19, with all 61 files, five plugin hashes
  and eight Mean-component cells per case. The [public-install summary](../native/mean-component-20261008/evidence/packaging/public-install-66d0278b.json)
  and [exact binding](../native/mean-component-20261008/evidence/packaging/public-install-binding-66d0278b.json)
  bind the tested source and final help bytes; this does not qualify other
  platform runtime or native Intel hardware. Source checks `37877625153` and
  all seven Rust-backend CI jobs in run `37877625154` also pass at `66d0278b`.
- The companion technical note in
  `technical-memos/centering/mean_centered_component_inference.tex` is complete,
  with a compiled and visually reviewed 13-page PDF, independent moment checks,
  and the assessment and numerical limits. The scoped five-file paper follow-up
  is committed and pushed at `9c6b27540485ec17aa1511f7dce502d67c5bbd93`;
  built-in compilation, PDF export and visual review pass. Scientific content
  and the 12 companion files remain unchanged; unrelated paper edits are
  preserved.

## Completed implementation and publication

The owner approved the source-first GitHub build/private Windows sequence and
up to 15 infrastructure repair cycles. Four were used before successful final
qualification; the serial Corrected repair was a separate project source
change. The later authority superseded the earlier single-retry stopping
instruction. Source and paper pushes are complete. All five native payloads,
source archives and reviewed local installation evidence are published at
`66d0278b`.
No tag, native release archive or hosted release has been made.

The adopted package and documentation were reviewed, committed and pushed at
`66d0278b`. All four public installation cases pass, with exact source and
installed-file bindings in the records above. This follow-up records those completed checks without
changing any installed file. Preserve all prior failures and original
Mac/Linux source identities and reuse limits. No scientific or platform scope
is expanded by the public Mac arm64 installation check.

## Preserved previous evidence

The immutable candidate checkpoint retains the initial Windows source-build
failures: `build_toolchain` return code 601 and `build_native` null return code,
both with cleanup and the machine stopped. The hosted-build alternative passed
81 offline tests and independent review. The later prebuilt smoke
`win-20261008T235353Z-856fd74e` failed artifact collection with zero accepted
artifacts despite positive controller Stata/project-test flags; cleanup and
shutdown passed. Subsequent repairs and the passing smoke do not relabel these
attempts. At `f8d74504`, smoke `win-20261009T014353Z-e95b12a1` passed,
but full run `win-20261009T015013Z-79411bd4` failed at `centering_exact` with
return code 498. That failure remains unchanged after the repaired-source
Windows retest passed.

`native/prerelease-20261008/manifest.json` retains its original Mac/Linux
point/Mean-projection claims at `24754269` (packaging `623b156d`, follow-up
`7fb65c41`). Its Windows payload remains unqualified. Earlier receipts and
registrations are immutable, including the observation-q1 SE-ratio failure at
1.101204 against 1.10 and the invalidated development pilot aggregate.

Current contracts live in [CENTERING.md](docs/CENTERING.md),
[INFERENCE.md](docs/INFERENCE.md) and [DECISIONS.md](docs/DECISIONS.md).
Engineering gates follow [development_acceptance_v1.json](docs/development_acceptance_v1.json).
