# Current decisions

## October 8, 2026: Mean component inference with the observed mean fixed

The owner accepts all five recommendations in
[the implementation plan](MEAN_COMPONENT_INFERENCE_PLAN.md): extend highrank
and q1 on every existing supported tuple, keep Mean as the default with
explicit output/metadata, perform independent algebra checks and a new bounded
sampling assessment, qualify the complete intended native platform set, and
review then commit/push the task changes and four existing package ancestors.
The companion technical note belongs in the separate paper repository. This
authorization does not include a package tag or hosted release.

Mean uses the retained physical-frequency working-outcome mean as a fixed
constant in realized influence, variance-proxy and q1 calculations. Inference
error probes remain uncentered. Exact Mata retains target-specific smoothing;
Rust retains residual-moment variance fitting. The approximation omits
mean-estimation uncertainty and is not inference conditional on the observed
mean. Fixed-offset nuisance uncertainty is a separate omission. Corrected
inference and all previously unsupported tuples remain withheld.

The active component returns are `e(inference_centering)` (`uncentered` or
`fixed observed mean`) and `e(inference_mean_omitted)` (`0` or `1`). Native Mean
component inference requires additive `component_centering_api=1`; native
Mean projection separately requires projection-centering API 1. Existing
combined exact-Mata requests support Mean; native combined component/projection
requests remain unsupported for Mean and None.
Existing ABI layouts and explicit None behavior remain. Historical source-
bound confirmations, failures and native receipts retain their scope and do
not qualify this extension. Pending assessment or platform results must not
be reported as passes; an incomplete platform set is not a complete qualified
distribution.

## October 7, 2026: Mean projection covariance

The owner requests Mean support for `project()`, using the same retained
frequency-weighted working-outcome mean as point centering. Mean is the
default; None remains available and Corrected projection is unsupported.
Target/projection weights keep their separate roles and do not redefine this
mean. Only the outcome factor in the symmetric leave-out covariance proxy
changes; fitted coefficients, residuals and naive covariance are unchanged.
At this checkpoint component inference remained None-only, including combined
requests; the October 8 decision above extends that scope.

This convention is translation invariant and follows Stata frequency weights.
It differs from the KSS Matlab main mover-match mean after square-root-mass
transformation. Estimated-mean bias is not corrected, and no uniform MSE or
finite-sample coverage advantage is claimed. Native Mean projection requires
separate projection-centering API 1. Previously adopted point-centering
payloads lack it. Rebuilt local Mac plugins pass development runtime checks;
historical distribution receipts do not qualify these new bytes or Mean
projection. See [CENTERING.md](CENTERING.md).

## October 7, 2026: Mean centering by default

The owner requests `centering(mean)` as the default for both exact and JLA.
Explicit `centering(none)` retains the former default; Corrected remains
opt-in. This changes option resolution, not the three estimators or their
MCSE conventions. At this checkpoint, active inference and projection required
explicit `centering(none)`; Mean projection is extended by the decision above.
An omitted option is not a fallback to None. Historical
receipts and Monte Carlo reports retain their original explicit modes.

## October 6, 2026: small outcome-centering scope

The initial implementation exposes only `centering(none|mean|corrected)`,
with None as its original default, superseded by the October 7 decision above.
Mean changes the correction factor with a retained frequency-weighted mean,
adds no solves/probes and uses ordinary MCSE with that observed mean fixed.
Corrected exact shares the existing inverse/deletion work and one correction
system. Corrected JLA uses the existing full/two-half leverage pools, requiring
even probes of at least four. Its MCSE is Mean's with the increment also fixed;
full numerical uncertainty for the increment is outside this implementation.

In this initial scope, active centering with inference/projection was
unsupported and rejected before RNG; the October 7 projection decision above
extends that scope. Failures do not silently substitute a mode. There are no
comparison
options, extra random pools, derivative/adjoint/replay machinery for the
increment, or automatic centering choices. Native centering API 1 is additive
and separate from numerical API 2. Source checks and exact-artifact Mac/Linux
qualification are complete, and the four matching local plugins are updated.
The owner authorized source commit/push on October 7. The Windows hosted
build passes, but full private qualification and a focused diagnostic fail.
The owner subsequently authorizes adoption of the exact candidate for manual
testing, with runtime qualification pending. No release or representative-scale/
statistical claim follows. [CENTERING.md](CENTERING.md)
records the method, assumptions, local timings and evidence.

## Inference

The component-inference items below record the decisions behind the exact and
structured models of 0.5.x. Those models were removed from the command on
2026-11-14 (0.6.0; see that section below); the `project()` and licensing
items remain current.

- Version `0.5.0-alpha.1` adds inference only by explicit request. Point-only
  behavior and the absence of `e(V)` on default calls are unchanged.
- Component `inference(highrank|q1)` defaults to Mata exact with observation
  deletion, movers, and unit frequency weights. Supported explicit
  `inferencemodel(structured_common|structured_leverage)` instead selects the
  Rust generic-JLA/Counter-V1 observation-deletion attachment for unit-
  frequency movers and joint nuisance handling with low-dimensional controls.
  The owner-approved fixed-offset match attachment is also explicit:
  `backend(rust) algorithm(jla) engine(generic) rng(counter_v1)` with
  `deletion(match) nuisance(fixedoffset) stayers(movers)`, a named structured
  model and `preconditioner(diagonal|cmg)`. It allows integer frequency mass
  and stored-row target weights. Point-estimation defaults are unchanged.
  Fixed-effect `project()` is a
  distinct surface: exact Mata and explicit Rust generic JLA support the
  requested observation or default match partition, positive integer
  frequency weights, and the default mover/eligible-stayer population.
- Scalable Rust component inference is a separately identified supported
  explicit method, never an automatic substitute for `inference(highrank)`. Its
  matrix-free core uses one common positive variance vector for the full joint
  covariance and leaves component point estimates unchanged. Strict
  unrestricted KSS variance products and the common structured FEVC variance
  regression are separate constructions. FEVC does not currently reserve or
  promise a strict unrestricted-KSS public mode. The structured model conditions primarily on
  leverage plus all three primitive target diagonals, with leverage-only as a
  sensitivity analysis; neither it nor the target-specific MATLAB/Mata LOWESS
  comparator may be called the unrestricted KSS estimator. Historical V5
  passed on its own source, but does not qualify the corrected q1 source.
  The corrected observation confirmation FAILS one unchanged SE-ratio gate
  (1.101204 versus 1.10), an unresolved RC limitation. The separately
  registered full match q0 and repaired match q1 confirmations PASS their
  primary gates. Severe omitted variance drivers visibly
  invalidated intervals without changing component point estimates. That
  limitation is part of the supported contract, not a robustness claim.
- The structured Rust `q=1` leading square is recentered by the raw leave-out
  product `sum_i v_i^2 y_i e_(i,-i)`. The common positive fitted variance
  vector is used only for leading/remainder covariance and studentization.
  A direct rank-one-remainder identity is a hard numerical gate. The public
  route uses at least 100,000 Counter-V1 critical draws. The registered V3
  factorized development campaign completed all 20,000 attempts, but the
  oracle t8 firm cell at dimension 64 again covered 0.972 and failed its fixed
  gate despite a `3.3e-13` remainder-identity error. The subsequent registered
  V4 diagnosis used 20,000 calibration and 10,000 independent evaluation
  replications at dimension 64. Production and analytic fixed-population q=1
  coverage were 0.9584--0.9591 under standardized-t8 and Gaussian errors; no
  one-component covariance substitution changed the result materially. Exact
  joint-Gaussian reference draws covered 0.9581--0.9593, while held-out
  calibration of the particular parabola's shortest required radius covered
  0.9483--0.9510. This is the intended conservatism of the KSS
  maximal-curvature, at-least-nominal construction, not a covariance,
  studentization, heavy-tail, decomposition, or ellipse-image defect. No
  production correction or empirical critical value was justified by that
  historical diagnosis. The subsequent curvature/recenter repair and fresh
  confirmations, not historical V5, govern the current source. `q=1` is
  supported only for target-specific one-mode regimes with a diffuse
  remainder; the deliberately multi-mode covariance target remains outside
  the coverage claim even when computation succeeds. No automatic
  concentration cutoff or `q` selection is authorized.
- Deletion unit, variance model, and reference distribution are independent
  dimensions. `q=1` never denotes match deletion. On 2026-09-05 the owner
  authorized public fixed-offset match q0/q1 integration using the separately
  passing confirmations, while retaining the failed corrected observation
  result. This prospective scope decision does not waive a scientific gate
  or approve release; see `fixed_offset_match_interface_v1.json`.
  Match inference collapses fixed-offset outcomes to declared matches and
  permits unrestricted within-match dependence, but assumes independent
  matches and a specified structured aggregate-variance model. The label is
  **Fixed-offset approximate match inference, ignoring nuisance-control
  estimation uncertainty.** Same-sample control estimation can violate the
  independence approximation even with few controls. No joint-controls or
  second-stage correction is included. Match mass/concentration, leverage,
  maker denominator and omitted-uncertainty diagnostics must be returned.
- `inference(highrank)` posts a polarized joint covariance for the three
  primitive targets and maps it to the four established targets.
  `inference(q1)` additionally posts rank-one weak-identification diagnostics
  and Anderson--Rubin-style intervals from repository-authored simulation and
  ellipsoid mapping.
- `project()` is a separate fixed-effect linear-projection surface. Its KSS
  covariance and naive residual-squared comparison are stored under
  `e(projection_*)`; projection alone never populates component `e(V)`.
- None projection covariance uses uncentered cross fitting. For observation units,
  `E[y_i ehat_{i,-i}|X]=sigma_i^2`. For declared match blocks it uses the
  symmetrized identity
  `.5*(y_g ehat_{g,-g}' + ehat_{g,-g} y_g')`, allowing unrestricted
  within-match covariance. The October 7 Mean option substitutes the
  frequency-centered working outcome in that proxy, with estimated-mean bias
  uncorrected. The exact unbiasedness identity is retained only for None under
  its stated assumptions.
- The explicit Rust/JLA sparse projection route accepts positive integer
  frequency weights as literal physical-copy counts. Frequency projection
  mass and the KSS/naive covariance are physical-copy weighted; explicit
  target mass remains stored-row mass.
- The sparse projection route accepts explicit `preconditioner(diagonal)` and
  forced `preconditioner(cmg)`. Forced CMG reuses the planned generic-JLA
  hierarchy, supports controls and weighted samples, and fails closed after
  selection. It is not the specialized compressed `CMG_FULL_V2` route.
  Automatic projection routing remains withheld so no existing projection
  request silently changes solver.
- The KSS Matlab package is a behavioral reference only. Its source and
  critical-value table are not licensed for copying and are not included.
  The implementation follows the published formulas and ships as
  MIT repository-authored source under the 2026-11-03 license decision.
- Materially negative smoothed variances or indefinite covariance estimates
  withhold the complete request. Only tiny registered roundoff values may be
  set to zero, and all such cleanups are receipted.

## Comparative-scaling right-censoring

- On 29 August 2026, the owner accepted the largest `strong_d2` one-core
  KSS Matlab cell as right-censored rather than authorizing another long rerun.
  KSS Matlab reached the registered 10,800-second estimator limit in
  all three position-balanced repetitions in both immutable production
  generations. The affected historical task IDs are 61, 62, and 63
  (`scale_strong_d2_n1966080_c1_r1` through `r3`).
- The accepted study therefore contains 297 complete same-host tasks and 891
  successful estimator calls. The three KSS Matlab lower bounds remain in a
  separate source-bound censor ledger. Partial Mata and Rust results from
  those sequential tasks do not enter the accepted call ledger.
- The entire graph--size--core cell is excluded from route rankings, paired
  ratios, and one-to-many-core scaling. This is a declared missing-cell rule,
  not an imputation or a relaxed numerical/application gate.
- Future comparative-scaling generations must not submit those three exact
  experiments. The executable record is
  [`future_exclusions.json`](../benchmarks/comparative_scaling/future_exclusions.json).

## Development priority and equivalence

- The primary product objective is a fast Stata alternative to KSS Matlab that returns the same statistical result on compatible problems.
  Corrected-result equivalence is first, end-to-end KSS Matlab competitiveness is
  second, and pathwise/backend-internal parity is secondary.
- The machine-readable policy is
  [`development_acceptance_v1.json`](development_acceptance_v1.json). For a
  corrected target pair `a,b`, let `s=max(1,abs(a),abs(b))`. Deterministic
  comparisons accept `abs(a-b)<=1e-8*s`; common-draw randomized comparisons
  additionally allow ten percent of the larger reported numerical MCSE.
  Independent-draw comparisons accept the greater of the scale floor and `6`
  times combined numerical MCSE. Comparators without MCSE use a registered
  repeated-seed distribution.
- The primary result comparison is the four corrected targets. Plug-in and
  correction rows, bitwise/ULP equality, iteration counts, counters, and
  reduction order remain valuable diagnostics but do not block a faster
  candidate whose corrected estimates pass the registered rule.
- Legacy source-bound receipts keep their original thresholds and statuses.
  Active development may reinterpret a legacy roundoff miss under the current
  policy without rewriting historical evidence.
- Test and qualification selection is impact-based. A new commit SHA alone
  does not require a full rerun. Large SCC arrays, broad platform matrices, and
  full native profiles require a material affected-surface reason, a benchmark
  or release question, risk that focused checks cannot bound, or an explicit
  owner request.
- Exact-source receipts remain immutable, but unaffected claims may be carried
  forward through a recorded compatibility review that identifies both source
  states, the changed paths, the relevant unchanged production/build/binary/
  input/acceptance identities, focused checks, reused claims, and limitations.
- Hard correctness still includes the same estimand/sample/target semantics,
  finite results, identification and accounting, complete original-system
  residuals, no hidden regularization or post-RNG estimator fallback, direct
  memory admission, typed failure/UserBreak, and caller-state/lifecycle
  restoration.
- A candidate is speed-competitive when its registered median complete-command
  time is no slower than KSS Matlab on the compatible comparison. The
  development target remains approximately one-half KSS Matlab time. Kernel-only
  or solver-only wins are diagnostic rather than sufficient.

## Package identity

- `fevc` is the only public command, help topic, package manifest, and
  installed package identity.
- No predecessor-command compatibility wrapper is installed.
- Distributed Mata/runtime filenames use `fevc*`; private Stata helpers use
  `_fevc_*`. Internal Mata symbols, plugin scalars, protocol/build IDs,
  environment variables, and Rust crate names retain their established
  `vckss__*`, `__vckss_*`, `VCKSS_*`, and `vckss-*` identities.

## Backend consent and defaults

- The alpha contract makes omitted `backend()` and `backend(auto)` prefer Rust
  only after a complete effective-request capability preflight.
- Missing runtime or a structurally unsupported tuple may fall back to Mata
  before native preparation and estimator RNG. Stale/corrupt receipts and all
  later failures fail closed.
- `backend(rust)` is strict and `backend(mata)` is explicit Mata.
- Omitted `rng()` and `rng(auto)` select Counter-V1 for Rust or Stata RNG for
  Mata. `rng(counter_v1)` is strict Rust consent; `rng(stata)` selects Mata and
  conflicts with strict Rust.
- Omitted `algorithm()` selects KSS Matlab-like JLA with 200 probes. Explicit
  `algorithm(auto)` retains exact-small/JLA-large structural planning.

## Automatic planning

- Algorithm, engine, solver route, fallback, batch width, memory, and wall
  planning resolve from the materialized retained structure before estimator
  RNG.
- The V7 execution plan is frozen. A later memory, rank, setup, convergence, or
  numerical failure cannot trigger a different estimator or engine.
- Explicit CMG fails closed. Automatic CMG-to-diagonal fallback is allowed only
  before RNG and must be recorded.
- Exact plans use no iterative route, probe batch, or estimator counter range.
- `memory_gib()` is optional. Omission forecasts and continues with no
  memory-based batch, concurrency or route choice. An explicit budget guides
  automatic batches and defaults to `memorycheck(warn)`; only `error`
  enforces forecast admission. `off` suppresses warnings/rejection but does
  not remove an explicit planning budget. Explicit batches are preserved.
- Native preparation is measured while it runs, and CMG forecasts are refined
  after deterministic setup before estimator RNG. Expected direct allocation
  and conditional admission reserve are separate from process RSS. The
  [memory guide](MEMORY.md) defines policy, timing, returns and accuracy limits.

## Scientific and numerical acceptance

- Point estimation remains the default; only an explicit accepted
  exact-observation component-inference request posts `e(V)`. Probe dispersion
  has no econometric interpretation.
- Omitted `deletion()` on a `project()` request therefore remains match
  deletion; projection inference never silently changes that default to
  observation deletion. Explicit observation deletion remains supported.
- Match deletion defaults to the KSS Matlab combined population:
  declared match blocks for movers and physical-observation deletion for
  eligible attached stayers. `stayers(movers)` is the mover-only opt-out.
- Frequency weights are literal positive integer copies; explicit target
  weights are stored-row target mass.
- Coefficient cells, deletion units, and exact target-scale strata remain
  separate.
- Every accepted RHS passes the complete original-system residual gate, target
  accounting identities, rank/estimability gates, policy-aware memory admission
  and receipt reconciliation, and finite-output checks.
- Omitted `tolerance()` uses `1e-10` for fit/deterministic solves and `1e-6`
  for randomized probes. An explicit value overrides both; effective phase
  tolerances and residual gates are receipted.
- No hidden regularization or silent change of sample, target, deletion,
  nuisance, algorithm, explicit tolerance, probe count, or route is permitted.

## Results and failure behavior

- Request, selection, execution-plan, memory, residual, counter, and
  caller-state receipts are part of the development contract.
- A result family is posted only by its matching poster: exact, compressed JLA,
  or generic JLA.
- Unsupported, inconsistent, unavailable, singular, unconverged, or
  resource-inadmissible states fail with a typed status. They do not fall back
  to a scientifically different command.

## Fixed-offset collapsed-match inference

- The explicit match-deletion component-inference family uses
  `nuisance(fixedoffset)` and holds fixed the full-sample estimated control
  offset. It does not estimate or add uncertainty from `gamma_hat`; joint-
  nuisance match inference is a separate future method.
- Within a declared match, the FE design row is constant. Conditional on the
  offset, regression mass `F_g`, the weighted offset-outcome mean, cell
  identity, and separately aggregated target mass are exact scalar sufficient
  statistics for the FE fit, component plug-ins, whole-match deletion,
  adjusted residual contraction, point correction, and component kernel.
- The inferential observations are declared matches, not physical rows or
  frequency-weight copies. Aggregate match errors may have unrestricted
  within-match covariance; declared matches are assumed independent.
- The primary match-variance model uses normalized midranks of match leverage,
  the three primitive collapsed target diagonals, and total match regression
  mass, with intercept, linear, square, and pairwise terms. The sensitivity
  fit uses only intercept, leverage, and leverage squared. No additional
  duration/support feature is admitted in the first model version.
- Cross-fitting the structured match-variance regression is a regularization
  device. It is not an independent-sample construction and does not turn the
  method into unrestricted-KSS inference.
- The grouped route is public only through the explicit match tuple listed
  above. Independent match q0 and repaired eligible q1 confirmations and
  macOS arm64/Rosetta native/install qualification pass; see
  `FIXED_OFFSET_MATCH_INTERFACE_2026-09-05.md`. It is never selected
  automatically, and the observation-only native entrypoint is unchanged.
- The first registered grouped q1 development campaign is a preserved
  scientific failure. Its exact execution and inventory complete, but the
  equal-mass structured-common and leverage-only cells miss the 0.98 success
  gate and the structured-common worker target modestly exceeds its frozen
  coverage ceiling among successful fits. Thresholds, targets, and failed
  attempts are not changed or conditioned away. That failure blocked the
  original development source. The separately registered repair and later
  passing confirmations supersede that development restriction, not its FAIL
  result. No new campaign is part of RC finalization.

## CMG ownership

- CMG is a package component, not a shared library or independent release.
- Its deterministic generator produces only the shipped `vckss_cmg` runtime
  and the checked-in `cmgtest` target.
- CMG API 9 adds command memory policy to the API 8 ownership/interface
  successor over the numerically qualified API 6 core; generator API 5 is
  unchanged.

## Evidence and release

- Historical reports, receipts, reviews, logs, manifests, and benchmark outputs
  are immutable source-bound evidence.
- Quick CI does not qualify the native plugin. Native claims require the
  source-local plugin profile and an exact-SHA receipt.
- Advisory timing, headroom or memory-budget misses do not withhold an
  otherwise admissible command. Actual allocation failures and malformed
  resource receipts remain errors under every memory policy.
- MIT governs covered code under the 2026-11-03 permission in `CODE_LICENSE.md`. The human package-boundary,
  corresponding-source, notice, provenance, and data-exclusion review was
  completed on 2026-08-29. Public tagging and release remain separate owner
  decisions, with a fresh exact-artifact check required before conveyance.

## 2026-09-25: original deletion units define match movers

Owner-authorized pooled-employer repair: match-mode movers have more than one
original deletion unit, not necessarily more than one model firm. Default
worker--firm IDs give the former classification. Freeze eligible one-block
stayers before graph pruning and synthetic observation IDs; do not reclassify
dropped movers. Preserve worker-articulation, bridge and full/nuisance-rank
gates, and the independence assumption across declared blocks. No new option
is needed. Gate all parallel partitions from old native selectors before
preparation; automatic routing uses Mata and strict Rust/Counter withholds.
See [contract](ESTIMATOR_CONTRACT.md) and
[validation notes](POOLED_DELETION_2026-09-25.md).

## 2026-09-26: native deletion-unit support

The Rust selector, final graph certificate and match-component inference guard
now use original deletion-unit support, matching Mata. Additive readiness bit
15 admits parallel blocks; the earlier fallback remains for older binaries.
No ABI layout, observation definition, articulation restriction or numerical
acceptance threshold changes. See the [integration record](DELETION_UNIT_MOVERS_2026-09-26.md)
for source-bound validation and platform qualification status.

## 2026-09-30: default numerical MCSE and orthogonal attachments

The owner selected public `mcse(all|off)`, default all, with conditional MCSE
retained as a developer option and `numericalmcse()` as a compatibility alias.
Main point MCSE can accompany supported projection or inference; their extra
results receive no MCSE. The native V2 interface preserves original point
executors and adds separate replay accounting, including existing Windows
routes. Binary refresh and scoped Linux SCC qualification are authorized;
release, CI policy and large cluster campaigns remain separate decisions.
See [the interface decision](MCSE_DEFAULT_INTERFACE_2026-09-30.md).

## 2026-11-10: leave-out residual standard errors

The owner chose a residual-based sampling standard error for the four
components over the KSS leave-two-out construction, accepted its stronger
assumption (similar error variances among units that share a worker or firm;
not robust to arbitrary heteroskedasticity), and decided that it should be
posted as `e(V)` by default with stated caveats once every default route can
carry it. `centering(corrected)` reports the mean-centred standard error and
treats the increment as fixed.

On the owner's further instruction the default is now `inference(auto)`:
standard errors are computed whenever the request can carry them, the user's
backend, algorithm and solver route are never changed, and a failed attempt
is repeated without them so that point estimates never depend on them.
`inference(none)` is the opt-out. The owner also accepted (i) one further
target pass under joint nuisance with controls, where the engine forms the
fixed-offset unit geometry beside the joint point estimate, (ii) running a
mover-only request without controls on the generic engine when standard
errors are attached, since the compressed engine carries no attachment and
both engines estimate the same quantities, and (iii) a separate Mata stage
for `algorithm(jla)` that draws its own projections. The registered
campaign example sources are unchanged; the owner has said they may be
changed and the campaigns rerun later if that becomes useful.

Additive readiness bit 18 and variance-source code 3 gate the native path; no
ABI layout changes. Shipped binaries predate the capability, so until they
are rebuilt the default reports point estimates and says why. The Stata and
Mata sources were written without access to Stata and are unexecuted; the
registered Stata suites keep the point-only default through
`FEVC_DEFAULT_INFERENCE=none`. See the
[technical supplement](standard_errors/standard_errors.tex).

## 2026-11-13: repeat-measurement standard errors and one interval per component by default

The owner asked for "a single method for calculating standard errors so
that the user doesn't really have to think about this": standard errors
that are "either high rank or Q1", with "the diagnostics ... run
automatically by the code to decide which one is appropriate", shown
"together with the information for the user", cheap, and available for the
exact estimate, for JLA and for the options a user chooses; centering with
a fixed centering value and controls as a fixed offset are acceptable to
him. On the plan proposed in reply he decided: "Q1 with interval and e(V)
only for high rank makes sense. The stata output should explain that"; the
leading direction is computed by default if it costs no more than about
100% of the point estimate alone; and the method is extended to observation
deletion.

Accordingly `inference(auto)`, the default, selects
`inferencemodel(repeat_measurement)`: error variances come from independent
repeat measurements wherever they exist (the rule he set on 2026-11-12,
with the more conservative model for the units without them), every
component is reported with the normal interval or the `q = 1` interval of
KSS Section 7.1, `e(V)` is posted only when all components are normal, and
the display says which interval each component received and why.
`inferencemodel(leaveout_residual)` keeps the default of 2026-11-10. The
guarantees of that decision stand: the selected backend, algorithm and
solver are never changed, and point estimates never depend on the standard
errors.

Not decided by the owner, and recorded for his review: the statistic of the
rule (the share of the estimated sampling variance carried by the leading
direction) and its threshold of ten per cent were chosen by the implementer
from development simulations; twenty per cent posts `e(V)` more often where
there is no bottleneck at a slightly lower worst-case coverage
([INFERENCE.md](INFERENCE.md), development table). The first registered
confirmation of the default as shipped failed its verdict on the inventory
of the outputs (one fit of 40,000 returned point estimates and the harness had
no rule for it); the second, with package, designs and tolerances
unchanged, met all of its tolerances (lowest coverage 0.930, mean 0.959,
40,000 fits, none failed, none returned point estimates). On three Veneto
panels the default adds 24% to 30% to the time of the point estimates and
reports normal intervals for every component. There is no theoretical
result for the data-dependent choice between the two intervals, and two or
more dominant directions are not covered. Control coefficients are treated
as known, which the owner accepted ("treating the control variables as
fixed offset"); a development check with a control strongly correlated
with the effects shows what that costs: the standard error of the sum is 9%
to 16% too small there and its interval covers 0.90 to 0.92
([INFERENCE.md](INFERENCE.md)). There is no simulation on the Mata routes
beyond the regression tests.

The distributed plugins predate the method; until they are rebuilt the
default reports point estimates and says why. Binaries, tag and release
remain separate owner decisions.

## 2026-11-14: control term, threshold, harness, release 0.6.0

The owner: "Ok add the control term. I think we stick with 10 percent for
the interval threshold. Harness can go into the repo. Afterwards we want to
merge this into main. Build and validate the plugins and release as 0.6.0".

Accordingly the threshold of the rule stays at ten per cent and is now the
owner's decision. The repeat-measurement standard errors and the `q = 1`
pieces include the estimation of the control coefficients to first order
(the variance of the fixed-offset estimate under the noise of the
control-adjusted outcome), on every route; this replaces the treatment of
the coefficients as known that the owner had accepted on 2026-11-13. The
joint estimate's additional term in the control index is not covered and
is stated as a limit; so are error variances that move with a control
inside a worker-firm cell and poorly identified coefficients
([INFERENCE.md](INFERENCE.md)). The Monte Carlo harness and the compact
records of its runs are in the repository (`tools/default_interval/`,
`docs/default_interval/`). The registered suites keep the point-only
default they were written for, and the command's own default has a test of
its own in every suite and qualifier. The version is 0.6.0.

The owner then asked: "what do you mean by: 'inferencemodel(leaveout_residual)
keeps the earlier default' What default? I thought the plan was that we were
offering only one way to get standard errors. explain." Offered three
options, he chose "Only the default". Accordingly the command computes the
standard errors of the components by one method, the repeat-measurement
model. `inferencemodel(leaveout_residual)`, added on 2026-11-10 and never
released, and the three experimental structured models of 0.5.2,
`inferencemodel(target_lowess)`, `inferencemodel(structured_common)` and
`inferencemodel(structured_leverage)`, are removed, with the options that
served only them (`inferencesimulations()`, `inferencebins()`,
`inferencegramprobes()`). A request for one of them stops before every other
check with `INFERENCE_MODEL_REMOVED` or `INFERENCE_OPTION_REMOVED` (return
code 198) and a message that names the change. `inference(highrank)` and
`inference(q1)` stay as interval overrides of the one method (normal
intervals only; the `q = 1` interval wherever it exists), and
`inferencemodel(repeat_measurement)` stays as an alias. Explicit
`inference(highrank|q1)` with `project()`, which 0.5.2 allowed on exact
Mata, stops with `COMPONENT_PROJECTION_COMBINATION_UNSUPPORTED`; `project()`
alone or beside the default is unchanged. The Mata and Rust machinery of
the removed models stays in the source, unreachable from the command, and
the plugin is unchanged; their documentation is that of the tag `v0.5.2`
([INFERENCE.md](INFERENCE.md), Removed in 0.6.0).

Merging into `main`, adopting the rebuilt binaries, tagging and publishing
remain the owner's to carry out. The Windows binary needs, besides, an
owner-approved change of the private runner's export list and a new
campaign protocol against 0.5.2 before its licensed qualification can run.

